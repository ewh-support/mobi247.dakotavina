<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-font" src="https://cdn.ampproject.org/v0/amp-font-0.1.js"></script>
<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom>body{font-family:'Roboto', sans-serif; font-size:14px; background-color:#FFFFFF;}

/*Color Schemes and Colors*/

.footer-logo{}
header{background-color:#1f1f1f; border-bottom:solid 1px rgba(0,0,0,0.1);}
nav{
    background: rgb(46,46,46);
    background: -moz-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(46,46,46,1)),color-stop(49%,rgba(31,31,31,1)),color-stop(50%,rgba(0,0,0,1)),color-stop(100%,rgba(0,0,0,1)));
    background: -webkit-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: -o-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: -ms-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: linear-gradient(to bottom,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#2e2e2e',endColorstr='#000000',GradientType=0);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#bcbcbc', endColorstr='#0a0809',GradientType=0 ); /* IE6-9 */filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#45484d', endColorstr='#000000',GradientType=0 ); /* IE6-9 */
}
nav a{color:#FFFFFF;}
.header-icon-1, .header-icon-2{color:#FFFFFF;}
.menu-item em{color:#000000; font-weight:500; font-size:12px; font-style: normal;}
.menu-item strong{color:#fd4c29; font-weight:500; font-size:14px;}
.header-clear{height:30px; display:block;}

.bg-teal-light{ background-color: #1abc9c; color:#FFFFFF}
.bg-teal-dark{  background-color: #16a085; color:#FFFFFF}
.border-teal-light{ border:solid 1px #1abc9c;}
.border-teal-dark{  border:solid 1px #16a085;}
.color-teal-light{ color: #1abc9c;}
.color-teal-dark{  color: #16a085;}
.bg-green-light{background-color: #2ecc71; color:#FFFFFF}
.bg-green-dark{background-color: #2abb67; color:#FFFFFF}
.border-green-light{border:solid 1px #2ecc71;}
.border-green-dark{ border:solid 1px #2abb67;}
.color-green-light{color: #2ecc71;}
.color-green-dark{color: #2abb67;}
.bg-blue-light{background-color: #3498db; color:#FFFFFF}
.bg-blue-dark{background-color: #2980b9; color:#FFFFFF;}
.border-blue-light{border:solid 1px #3498db;}
.border-blue-dark{ border:solid 1px #2980b9;}
.color-blue-light{color: #3498db;}
.color-blue-dark{color: #2980b9;}
.bg-magenta-light{background-color: #9b59b6; color:#FFFFFF}
.bg-magenta-dark{background-color: #8e44ad; color:#FFFFFF}
.border-magenta-light{border:solid 1px #9b59b6;}
.border-magenta-dark{ border:solid 1px #8e44ad;}
.color-magenta-light{color: #9b59b6;}
.color-magenta-dark{color: #8e44ad;}
.bg-night-light{background-color: #34495e; color:#FFFFFF}
.bg-night-dark{background-color: #2c3e50; color:#FFFFFF}
.border-night-light{border:solid 1px #34495e;}
.border-night-dark{ border:solid 1px #2c3e50;}
.color-night-light{color: #34495e;}
.color-night-dark{color: #2c3e50;}
.bg-yellow-light{background-color: #E67E22; color:#FFFFFF}
.bg-yellow-dark{background-color: #e86f2a; color:#FFFFFF}
.border-yellow-light{border:solid 1px #E67E22;}
.border-yellow-dark{ border:solid 1px #F27935;}
.color-yellow-light{color: #f1c40f;}
.color-yellow-dark{color: #f39c12;}
.bg-orange-light{background-color: #F9690E; color:#FFFFFF}
.bg-orange-dark{background-color: #D35400; color:#FFFFFF}
.border-orange-light{border:solid 1px #F9690E;}
.border-orange-dark{ border:solid 1px #D35400;}
.color-orange-light{color: #e67e22;}
.color-orange-dark{color: #d35400;}
.bg-red-light{background-color: #e74c3c; color:#FFFFFF}
.bg-red-dark{background-color: #c0392b; color:#FFFFFF}
.border-red-light{border:solid 1px #e74c3c;}
.border-red-dark{ border:solid 1px #c0392b;}
.color-red-light{color: #e74c3c;}
.color-red-dark{color: #c0392b;}
.bg-pink-light{background-color: #fa6a8e ; color:#FFFFFF}
.bg-pink-dark{background-color: #FB3365 ; color:#FFFFFF}
.border-pink-light{border:solid 1px #fa6a8e ;}
.border-pink-dark{ border:solid 1px #FB3365 ;}
.color-pink-light{color: #fa6a8e;}
.color-pink-dark{color: #FB3365;}
.bg-gray-light{background-color: #bdc3c7; color:#FFFFFF}
.bg-gray-dark{background-color: #95a5a6; color:#FFFFFF}
.border-gray-light{border:solid 1px #bdc3c7;}
.border-gray-dark{ border:solid 1px #95a5a6;}
.color-gray-light{color: #bdc3c7;}
.color-gray-dark{color: #95a5a6;}
.bg-white{background-color:#FFFFFF;}
.color-white{color:#FFFFFF;}
.border-white{border:solid 1px #FFFFFF;}
.bg-black{background-color:#000000;}
.color-black{color:#000000;}
.border-black{border:solid 1px #000000;}
.color-heading{color:#676767;}

/*Social Icons*/
.facebook-bg{background-color:#3b5998; color:#FFFFFF;}
.linkedin-bg{background-color:#0077B5; color:#FFFFFF;}
.twitter-bg{background-color:#4099ff; color:#FFFFFF;}
.google-bg{ background-color:#d34836; color:#FFFFFF;}
.whatsapp-bg{ background-color:#34AF23; color:#FFFFFF;}
.pinterest-bg{ background-color:#C92228; color:#FFFFFF;}
.sms-bg{ background-color:#27ae60; color:#FFFFFF;}
.mail-bg{ background-color:#3498db; color:#FFFFFF;}
.dribbble-bg{ background-color:#EA4C89; color:#FFFFFF;}
.tumblr-bg{ background-color:#2C3D52; color:#FFFFFF;}
.reddit-bg{ background-color:#336699; color:#FFFFFF;}
.youtube-bg{ background-color:#D12827; color:#FFFFFF;}
.phone-bg{ background-color:#27ae60; color:#FFFFFF;}
.skype-bg{ background-color:#12A5F4; color:#FFFFFF;}
.facebook-color{    color:#3b5998;}
.linkedin-color{    color:#0077B5;}
.twitter-color{     color:#4099ff;}
.google-color{      color:#d34836;}
.whatsapp-color{    color:#34AF23;}
.pinterest-color{   color:#C92228;}
.sms-color{         color:#27ae60;}
.mail-color{        color:#3498db;}
.dribbble-color{    color:#EA4C89;}
.tumblr-color{      color:#2C3D52;}
.reddit-color{      color:#336699;}
.youtube-color{     color:#D12827;}
.phone-color{       color:#27ae60;}
.skype-color{       color:#12A5F4;}

/*Background Images*/
.bg-1{background-image:url(images/pictures/1.jpg)}
.bg-2{background-image:url(images/pictures/2.jpg)}
.bg-3{background-image:url(images/pictures/3.jpg)}
.bg-4{background-image:url(images/pictures/4.jpg)}
.bg-5{background-image:url(images/pictures/5.jpg)}
.bg-6{background-image:url(images/pictures/6.jpg)}
.bg-7{background-image:url(images/pictures/7.jpg)}
.bg-8{background-image:url(images/pictures/8.jpg)}
.bg-9{background-image:url(images/pictures/9.jpg)}
.bg-body-1{background-image:url(images/pictures_vertical/bg1.jpg)}
.bg-body-2{background-image:url(images/pictures_vertical/bg0.jpg)}
.overlay{background-color:rgba(0,0,0,0.8); position:absolute; top:0px; right:0px; bottom:0px; left:0px;}

/*Font Settings*/
h1{ font-size:24px; line-height:34px; font-weight:500;}
h2{ font-size:22px; line-height:32px; font-weight:500;}
h3{ font-size:20px; line-height:30px; font-weight:500;}
h4{ font-size:18px; line-height:28px; font-weight:500;}
h5{ font-size:16px; line-height:26px; font-weight:500;}
h6{ font-size:14px; line-height:22px; font-weight:800;}
.ultrathin{font-weight:200;}
.thin{font-weight:300;}
.thiner{font-weight:400;}
.boder{font-weight:600;}
.bold{font-weight:700;}
.ultrabold{font-weight:800;}
.capitalize{text-transform: capitalize;}
.italic{font-style: italic;}
.small-text{font-size:12px; display:block;}
.center-text{text-align:center; display:block;}
.right-text{text-align:right;}
.uppercase{text-transform: uppercase;}
.boxed-text{width:74%; margin:0px auto 30px auto;}
.round-image{border-radius:500px;}
p a{display:inline;}

/*Content Settings*/
.content{padding:0px 20px 0px 20px}
.container{margin-bottom:30px}
.full-bottom{margin-bottom:25px}
.no-bottom{margin-bottom:0px}
.negative-bottom{margin-bottom:-10px;}
.full-top{margin-top:25px}
.half-bottom{margin-bottom:15px}
.half-top{margin-top:15px}
.quarter-bottom{margin-bottom:15px}
.hidden{display:none}
.left-column{width:45%; margin-right:5%; float:left}
.right-column{width:45%; margin-left:5%; float:left}
.one-third-left{float:left; width:29%;  margin-right:1%}
.one-third-center{float:left; width:29%; margin-left:5%; margin-right:5%}
.one-third-right{float:left; width:29%; margin-left:1%}
.clear{clear:both;}

* {
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	vertical-align: baseline;
	outline: none;
	font-size-adjust: none;
	-webkit-text-size-adjust: none;
	-moz-text-size-adjust: none;
	-ms-text-size-adjust: none;
	-webkit-tap-highlight-color: rgba(0,0,0,0);
    -webkit-font-smoothing: antialiased;
    -webkit-transform: translate3d(1,1,1);
    transform:translate3d(1,1,1);    
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

div, a, p, img, blockquote, form, fieldset, textarea, input, label, iframe, code, pre {
	display: block;
	position:relative;
}

p{
	line-height:30px; 
	font-weight:400; 
	color:#666666; 
	font-size:14px; 
	margin-bottom:30px;
}

a{text-decoration:none; color:#3498db;} 

/*Lists*/
.icon-list{list-style:none; font-size:14px; line-height:35px; color:#666666;}
.icon-list i{width:30px; font-size:15px;}

.center-icon{
	width:80px;
	height:80px;
	border-radius:80px;
	border:solid 1px rgba(0,0,0,0.5);
	text-align:center;
	line-height:80px;
	font-size:24px;
	margin:0px auto 30px auto;
	display:block;
}

.decoration, .decoration-no-bottom{
	height:1px; 
	background-color:rgba(0,0,0,0.1);
}

.deco{height:1px; margin-bottom:30px;}

.deco-box .deco{
	width:10%;
	float:left;
	height:5px;
}

.decoration{margin-bottom:30px;}
.decoration-margins{margin:0px 20px 30px 20px}

/*Image Effect*/

.image-border{
	padding:10px;
	border:solid 6px #FFFFFF;
	-webkit-box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
	box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
	border-radius:5px;
}

/*Page Content*/

::-webkit-scrollbar { width: 0; }

.menu *{
	user-select: none;
	-moz-user-select: none;
	-webkit-user-select: none;
}

/*Header*/
header{
	top:0px;
	height:55px;
	width:100%;
	z-index:9999;
	transition:all 250ms ease;
}

.footer-logo{
	background-image:url(images/logo_dark.png);
	margin:0 auto 10px auto;
	background-repeat: no-repeat;
	background-position:center center;
	background-size:130px 40px;
	width:130px;
	height:40px;
	display:block;
	overflow:hidden;
}

.header-icon-1, .header-icon-2{
	position:absolute;
	line-height:60px; 
	text-align:center; 
	width:60px;
	display:block;
	background-color:transparent;
}

.header-icon-2{
	right:0px; 
	top:0px;
}

.header-icon-1{
	left:0px;
	top:0px;
}

.header-logo{
	background-image:url(images/logo_light.png);
	margin:0 auto;
	background-repeat: no-repeat;
	background-position:center center;
	background-size:100px 29px;
	width:105px;
	height:60px;
	display:block;
	overflow:hidden;
}

/*Navigation*/

nav{
	z-index:9999999;
	height:60px;
	position:fixed;
	bottom:0px;
	left:0px;
	right:0px;
}

.copyright{margin-bottom:90px; margin-top:30px;}

.footer-7-icons a{width:14.285714%;}
.footer-6-icons a{width:16.6667%;}
.footer-5-icons a{width:20%;}
.footer-4-icons a{width:25%;}
.footer-3-icons a{width:33.333%;}

nav a{
	box-sizing: border-box;
	float:left;
	text-align:center;
	font-size:15px;
	height:60px;
	border-right:solid 1px rgba(255,255,255,0.05);
	border-left:solid 1px rgba(0,0,0,1);
}
nav a i{
	margin-top:13px;
	display:block;
	height:23px;
	line-height:23px;
}

nav a em{
	display:block;
	font-size:10px;
	opacity:0.8;
	text-transform:uppercase;
	font-style:normal;
}

.active-item{background-color:rgba(255,255,255,0.08);}

.footer{margin-bottom:80px;}

.icon-12{font-size:12px;}
.icon-13{font-size:13px;}
.icon-14{font-size:14px;}
.icon-15{font-size:15px;}
.icon-16{font-size:16px;}
.icon-17{font-size:17px;}
.icon-18{font-size:18px;}
.icon-19{font-size:19px;}
.icon-20{font-size:20px;}


.footer-socials a{
	width:40px;
	height:40px;
	line-height:40px;
	margin-left:2px;
	margin-right:2px;
	text-align:center;
	float:left;
	border-radius:5px;
}

.footer-socials{
	width:265px;
	margin:0px auto 30px auto;
}


/*Icons & Captions*/

.news-slider .caption{
	background-color:rgba(0,0,0,0.8);
}

.caption{
	position:absolute;
	bottom:0px;
	left:0px;
	right:0px;
	height:65px;
	padding-left:20px;
	padding-right:20px;
	background-color:rgba(0,0,0,0.8);
}

.caption h4{
	font-size:14px;
	color:#FFFFFF;
	line-height:20px;
	margin-top:12px;
}

.caption h3{
	color:#FFFFFF;
	margin-bottom:5px;
	font-size:17px;
	padding-top:23px;
	line-height:0px;
}

.caption p{
	font-size:12px;
	color:rgba(255,255,255,0.5);
}


.call-to-action{
	width:245px;
	margin:0 auto;
}

.call-to-action a{margin:0px 5px; font-size:11px;}


.social-icons{
	width:150px;
	margin:0 auto;
}

.social-round a{border-radius:50px;}

.social-icons-small{
	width:95px;
	margin:0 auto;
}

.social-icons a{
	line-height:35px;
	width:35px;
	height:35px;
	margin-left:10px;
	margin-right:5px;
	float:left;
	font-size:12px;
}

.social-icons-small a{
	line-height:35px;
	width:35px;
	height:35px;
	margin-left:5px;
	margin-right:5px;
	float:left;
}

/*Large Link*/
.large-link{
	font-size:13px;
	height:50px;
	line-height:50px;
	color:#000000;
	border-bottom:solid 1px rgba(0,0,0,0.1);
}

.large-link .fa-caret-right{
	font-size:10px;
	position:absolute;
	right:-25px;
	line-height:50px;
}

.large-link .fa-angle-right{
	position:absolute;
	right:0px;
	height:50px;
	line-height:50px;
	width:10px;
}

.large-link-deco{height:1px; margin-bottom:3px; background-color:rgba(0,0,0,0.1);}
.large-link i:last-child{width:20px; margin-right:20px; text-align:center;}


/*Heading Block*/
.heading-box{padding:20px 20px 20px 20px; margin-bottom:30px;}
.heading-box h3{margin-bottom:-5px; font-size:17px; position:relative; z-index:10;}
.heading-box p{position:relative; z-index:10; margin-bottom:0px; color:rgba(255,255,255,0.4);}
.heading-box i{padding:0px 5px 0px 5px;}

.heading-block{
	padding:30px 20px;
	margin-bottom:30px;
}

.heading-block h4{
	font-size:20px;
	position:relative;
	z-index:10;
	color:#FFFFFF;
}

.heading-block p{
	position:relative;
	z-index:10;
	color:rgba(255,255,255,0.5);
	margin-bottom:0px;
}

.heading-block a{
	z-index:10;
	width:100px;
	height:10px;
	line-height:10px;
	color:#FFFFFF;
	text-align:center;
	font-size:12px;
	margin:20px auto 0px auto;
	border:solid 1px rgba(255,255,255,0.5);
	border-radius:5px;
    display:block;
	text-transform: uppercase;
	font-weight:800;
}

.icon-heading h4{
	padding-left:80px;
	font-size:15px;
}

.icon-heading p{
	line-height:24px;
	padding-left:80px;
}

.icon-heading i{
	border-radius:10px;
	position:absolute;
	width:70px;
	height:70px;
	line-height:70px;
	margin-top:5px;
	text-align:center;
	font-size:24px;
}

.icon-heading amp-img{
	width:55px;
	height:55px;
	margin-left:0px;
	margin-top:10px;
	float:left;
}

.quote-style h4, .quote-style h5{
	font-weight:300;
	margin-left:25px;
	margin-right:25px;
	text-align:center;
	line-height:40px;
}

.rating{
	width:80px;
	margin:20px auto 20px auto;
	display:block; 
}


.half-column-left .half-left-img{
	position:absolute;
	border-radius:150px;
	margin-left:-50px;
	left:0px;
}

.half-column-left{
	padding-left:70px;
	padding-right:20px;
	min-height:150px;
    overflow:hidden;
}


.half-column-right .half-right-img{
	position:absolute;
	border-radius:150px;
	margin-right:-50px;
	right:0px;
}

.half-column-right{
	padding-right:70px;
	padding-left:20px;
	min-height:150px;
    overflow:hidden;
}

/*Gallery*/
.gallery-thumb{
	width:31%;
	float:left;
	margin-bottom:3%;
	box-sizing: border-box;
}
.gallery-thumb p{margin-bottom:10px; line-height:20px; padding-top:5px; text-align:center; font-size:13px;}
.gallery-round .gallery-thumb{border-radius:100px}
.gallery-wide .gallery-thumb-wide{margin-bottom:5px;}
.gallery-wide h4{
	position:absolute;
	background-color:rgba(0,0,0,0.8);
	color:#FFFFFF;
	z-index:99;
	height:50px;
	line-height:50px;
	margin-top:-55px;
	width:100%;
	padding-left:20px;
	font-weight:300;
	font-size:14px;
	pointer-events:none;
}


.gallery-thumb:nth-child(3n-1){
	margin-left:3%;
	margin-right:3%;
}

.gallery-text{font-size:12px; color:#939393; line-height:24px;}
.gallery-text i{font-size:11px; padding:0px 10px 0px 0px;}
.gallery-text em{padding:0px 15px 0px 0px; font-style:normal}


/*Splash Page*/
.splash-content .splash-logo{
	background-image:url(images/amp-logo.png);
	background-size:80px 80px;
	width:80px;
	height:80px;
	margin:-30px auto 20px auto;
}

.splash-content{
	position:fixed;
	width:240px;
	height:350px;
	left:50%;
	top:50%;
	margin-top:-140px;
	margin-left:-120px;
}

.splash-button{
	width:130px;
	margin:0 auto;
	text-align:center;
	height:40px;
	line-height:40px;
	font-size:12px;
}

/*Landing Content*/

.landing-logo{
	background-image:url(images/logo_light.png);
	background-size:160px 47px;
	margin:0 auto;
	height:47px;
	width:160px;
	margin-top:20px;
}

.landing-content{
	width:300px;
	margin:40px auto 30px auto;
}

.landing-content a{
	width:70px;
	height:70px;
	float:left;
	margin:0px 15px 60px 15px;
	border-radius:70px;
	line-height:70px;
	font-size:21px;
	text-align:center;
}

.landing-content a em{
	position:absolute;
	font-size:14px;
	width:70px;
	text-align:center;
	bottom:-60px;
	left:0px;
	right:0px;
	font-style:normal;
}

.body-bg{
	background-image:url(images/pictures_vertical/bg2.jpg);
	position:fixed;
	top:0px;
	left:0px;
	right:0px;
	bottom:0px;
}

/*Accordion Styles*/
.accordion h4{
	background-color:transparent;
	border:none;
}

.accordion h4{
	font-size:16px;
	line-height:40px;
}

.accordion h4 i{
	height:40px;
	line-height:40px;
	position:absolute;
	right:0px;
	font-size:12px;
}

.nested-accordion h4{
	font-size:14px;
}

section[expanded] .fa-plus{	transform:rotate(45deg);}
section[expanded] .fa-angle-down{	transform:rotate(180deg);}
section[expanded] .fa-chevron-down{	transform:rotate(180deg);}

/*Fonts*/
.demo-icons a{
	color:#FFFFFF; 
	width:20%;
	height:50px;
	float:left;
}
.demo-icons a i{
	color:#1f1f1f; 
	font-size:21px;
	width:50px;
	height:50px; 
	float:left; 
	text-align:center; 
	overflow:hidden;
}

/*User Notifications*/
.user-notification{
	text-align:left;
	padding-top:5px;
	padding-left:10px;
	padding-right:10px;
	background-color:#27ae60;
	height:50px;
	color:#FFFFFF;
	font-size:12px;
	line-height:24px;
	width:70%;
	float:left;
}

.user-notification button{
	background-color:#27ae60;
	color:#FFFFFF;
	height:55px;
	position:fixed;
	right:0px;
	bottom:60px;
	width:25%;
}

/*Inputs*/

.text-input{
	height:45px;
	line-height:45px;
	text-indent: 10px;
	border:solid 1px rgba(0,0,0,0.1);
	display:block;
	width:100%;
	font-size:12px;
}

.input-icon-field{
	height:45px;
	line-height:45px;
	text-indent: 50px;
	border:solid 1px rgba(0,0,0,0.1);
	display:block;
	width:100%;
	font-size:12px;
}

.input-icon i{
	position:absolute;
	z-index:9;
	height:45px;
	line-height:45px;
	text-align:center;
	width:45px;
	color:#666666;
}

.select-style {
    border: 1px solid rgba(0,0,0,0.1);
    width: 100%;
	height:45px;
	display:block;
    border-radius: 3px;
    overflow: hidden;
    background: #FFFFFF url("data:image/png;base64,R0lGODlhDwAUAIABAAAAAP///yH5BAEAAAEALAAAAAAPABQAAAIXjI+py+0Po5wH2HsXzmw//lHiSJZmUAAAOw==") no-repeat 95% 50%;
}

.select-style select {
	font-size:12px;
	line-height:35px;
    padding: 5px 15px;
    width: 100%;
    border: none;
    box-shadow: none;
    background-color:rgba(255,255,255,0);
    background-image: none;
    -webkit-appearance: none;
}

.select-style select:focus {
    outline: none;
}



/*Dropcaps*/

.dropcaps-1:first-letter{
    float:left;
    font-size:57px;
	padding:14px 15px 0px 0px;
    font-weight:800;
    color:#1f1f1f;
}

.dropcaps-2:first-letter{
    font-family: 'Times New Roman', sans-serif;
    float:left;
    font-size:42px;
	padding:15px 15px 0px 0px;
    font-weight:800;
    color:#1f1f1f;
}

.dropcaps-3:first-letter{
    background-color:#1f1f1f;
	padding:10px 15px 10px 15px;
	margin:5px 12px 0px 0px;
    float:left;
    font-size:24px;
    font-weight:800;
    color:#FFFFFF;
}

.dropcaps-4:first-letter{
    font-family: 'Times New Roman', sans-serif;
    font-weight:800;
    background-color:#1f1f1f;
	padding:8px 17px 8px 17px;
	margin:5px 12px 0px 0px;
    float:left;
    font-size:20px;
    font-weight:400;
    color:#FFFFFF;
}

/*Highlights*/
.highlight{margin-bottom:10px;}
.highlight span{padding:3px 5px 3px 5px; margin-right:2px;}
ol ul{	padding-left:5px;}
ol, ul{line-height:24px; margin-left:20px;}
.icon-list{list-style:none; margin-left:0px; padding-left:0px;}
.icon-list i{font-size:10px;}
.icon-list ul{list-style:none; padding-left:10px;}
.icon-list ul ul{padding-left:10px;}

/*Blockquotes*/
.blockquote-1{border-left:solid 3px #1f1f1f; padding:10px 0px 10px 20px;}
.blockquote-1 a{text-align:right; margin-top:-20px;  font-size:12px;}
.blockquote-2 .blockquote-image{position:absolute; border-radius:50px;}
.blockquote-2 h5{padding-left:60px;}
.blockquote-2 .first-icon{padding-left:60px;}
.blockquote-2 a{text-align:right; margin-top:-20px; font-size:12px;}
.blockquote-3 .blockquote-image{width:150px; border-radius:150px; margin:0 auto; display:block;}
.blockquote-3 h5{margin:10px 0px 10px 0px;}
.blockquote-3 .ratings{width:100px; margin:10px auto 10px auto;}
.blockquote-3 .ratings i{font-size:18px;}
.blockquote-4 i{font-size:24px; position:absolute; margin-top:10px;}
.blockquote-4 p{padding-left:50px;}
.blockquote-5 amp-img{width:50px; height:50px; margin:0 auto;}
.blockquote-5 h4{font-size:24px; font-weight:200;}
.blockquote-5 p{font-style:italic; max-width:80%; font-weight:300; margin:0 auto; color:#747474; font-size:16px; line-height:35px;}

/*Buttons*/
.button{
	display:inline-block;
	padding:13px 20px;
	margin:0px 0px 10px 0px;
	font-size:12px;
	transition:all 250ms ease;
}

.button-3d{
	display:inline-block;
	padding:15px 20px;
	margin:0px 0px 10px 0px;
	font-size:12px;
	transition:all 250ms ease;
	border-right:none;
	border-left:none;
	border-top:none;
	border-width:3px;
}

.button-round{border-radius:30px;}
.button-full{display: block; text-align: center;}
.button-center{width:140px; margin-left:auto; margin-right:auto; display:block; text-align:center; margin-bottom:30px;}
.button:hover{opacity:0.9; transition:all 250ms ease;}

.icon-square, .icon-round{
	width:40px;
	height:40px;
	line-height:40px;
	text-align:center;
	display:inline-block;
	margin-left:6px;
	margin-right:6px;
	margin-bottom:10px;
	font-size:14px;
}
.icon-square:hover, .icon-round:hover{opacity:0.9;}
.icon-round{border-radius:45px;}

/*Page 404*/
.page-404 h1{font-size:60px; line-height:70px; margin-top:70px;}
.page-404 a{margin-bottom:100px;}
.page-soon h1{font-size:60px; line-height:70px; margin-top:70px;}
.page-soon h6{font-size:24px;}
.page-soon .social-icons{margin-bottom:100px;}

/*Profile Page*/

.profile-gradient{
    background: -moz-linear-gradient(top,rgba(255,255,255,0) 0%,rgba(255,255,255,0.95) 75%,rgba(255,255,255,1) 100%);
    background: -webkit-linear-gradient(top,rgba(255,255,255,0) 0%,rgba(255,255,255,0.95) 75%,rgba(255,255,255,1) 100%);
    background: linear-gradient(to bottom,rgba(255,255,255,0) 0%,rgba(255,255,255,0.95) 75%,rgba(255,255,255,1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00ffffff',endColorstr='#ffffff',GradientType=0);
    height: 250px;
    margin-top: -235px;
}

.profile-overlay .profile-header{margin-top:-80px}
.profile-header h1{font-size:30px;}
.profile-header h6{letter-spacing:2px; opacity:0.5;}
.profile-header h5{font-size:12px;}
.profile-header i{margin-right:10px;}
.profile-header p{font-size:18px;}
.profile-followers a{float:left; width:33%; color:#1f1f1f; font-size:18px;}
.profile-followers em{display:block; font-style:normal; font-size:12px;}
.profile-thumb{margin-top:-50px; width:100px; margin-left:auto; margin-right:auto; display:block; border-radius:100px; border-radius:100px; border:solid 3px #FFFFFF;}

/*Timeline 1*/

.timeline-1{overflow:hidden; padding:20px }

.timeline-1 .timeline-deco{
	position:absolute;
	top:0px;
	left:50%;
	width:1px;
	bottom:0px;
	background-color:rgba(0,0,0,0.15);
}

.timeline-1 .timeline-icon{
	width:60px;
	height:60px;
	border-radius:60px;
	line-height:60px;
	text-align:center;
	font-size:18px;
	background-color:#FFFFFF;
	border:solid 1px rgba(0,0,0,0.2);
	margin:0px auto 30px auto;
}

.timeline-1 .container{background-color:#FFFFFF; padding:30px 0px 1px 0px}
.timeline-2{overflow:hidden; padding:50px 20px 0px 20px; }

.timeline-2 .timeline-deco{
	position:absolute;
	top:0px;
	left:50px;
	width:1px;
	bottom:0px;
	background-color:rgba(0,0,0,0.15);
}

.timeline-2 .timeline-icon{
	width:40px;
	height:40px;
	border-radius:40px;
	line-height:40px;
	text-align:center;
	font-size:18px;
	background-color:#FFFFFF;
	border:solid 1px rgba(0,0,0,0.2);
	margin-left:10px;
}

.timeline-2 .container{
	background-color:#FFFFFF; 
	margin-left:70px;
	margin-top:-60px;
	padding-bottom:30px;
}


/*News Slider*/

.news-slider .amp-carousel-button{display:none;}
.news-slider{margin-bottom:10px;}

/*News Thumbs*/

.news-thumbs .news-item{
	min-height:125px;
	color:#1f1f1f;
}

.news-thumbs .news-item .responsive-img{
	width:95px;
	position:absolute;
	margin-top:5px;
}

.news-thumbs .news-item h5{
	margin-left:110px;
	font-size:15px;
}

.news-thumbs .news-item p{
	margin-left:110px;
	line-height:27px;
	margin-bottom:0px;
	font-size:13px;
}

/*News Strip*/

.news-strip{
	background-color:#000000;
	padding:20px 0px 20px 0px;
	margin-bottom:30px;
}

.news-strip h5{
	font-weight:800;
	color:#FFFFFF;
	padding:0px 20px 20px 20px;
}

/*News Cateogry*/

.news-category{
	margin:0px 20px 0px 20px;
}

.news-category p{
	display:inline-block;
	padding:5px 25px 0px 25px;
	font-size:13px;
	margin:0px;
}

.news-category div{
	height:5px;
	width:100%;
}

/*News Block*/

.news-blocks .news-item{
	min-height:125px;
	color:#1f1f1f;
}

.news-blocks .news-item h5{
	font-size:18px;
	padding:15px 0px 5px 0px;
}

/*News full*/

.news-full .news-item{margin-top:1px;}

.news-full .news-item h6{
	position:absolute;
	background-color:rgba(0,0,0,0.8);
	bottom:0px;
	width:100%;
	color:#FFFFFF;
	padding:10px 10px 10px 10px;
}

.news-full .titles{
	position:absolute;
	background-color:#FFFFFF;
	width:250px;
	height:65px;
	margin-top:-65px;
}

.news-full h5{
	font-size:13px;
	padding:10px 20px 0px 20px;
	color:#000000;
}
.news-full em a{display:inline;}
.news-full em{font-size:10px; padding-left:20px; display:block;}
.news-full p{padding:10px 20px 0px 20px;}
.news-full .read-more{
	padding-right:20px;
	text-align:right;
	font-size:12px;
	padding-bottom:30px;
}

/*News Posts*/

.news-post-info{
	font-style:normal;
	font-size:12px;
	padding:5px 0px 15px 0px;
	display:block;
}

.news-post-info a{
	display:inline;
	
}

/*Contact Page*/

.contactField{
	font-family:'Roboto', sans-serif;
	height:40px;
	line-height:40px;
	line-height:100%;
	width:100%;
	display:block;
	border:solid 1px rgba(0,0,0,0.1);
	text-indent:10px;
	font-size:13px;
	transition:all 250ms ease;
	margin-bottom:20px;
}

.contactField:focus{
	border:solid 1px rgb(39, 174, 96);
	transition:all 250ms ease;
}

.contactTextarea{
	font-family:'Roboto', sans-serif;
	padding-top:10px;
	min-height:80px;
	line-height:40px;
	line-height:100%;
	width:100%;
	display:block;
	border:solid 1px rgba(0,0,0,0.1);
	text-indent:10px;
	font-size:13px;
	transition:all 250ms ease;
	margin-bottom:30px;
}

.contactTextarea:focus{
	transition:all 250ms ease;
	border:solid 1px rgb(39, 174, 96);
}

.field-title{
	font-size:13px; 
	margin-bottom:5px;
}

.field-title span{
	font-size:10px;
	color:#cacaca;
	position:absolute;
	right:0px;
	margin-top:2px;
}

.buttonWrap{
	width:100%;
	display:block;
	text-align:center;
	margin-bottom:30px;
    appearance:none;
    -webkit-appearance:none;
}

.contact-icon{
	color:#666666;
	line-height:30px;
}

.contact-icon i{
	color:#1f1f1f;
	width:30px;
}


/*Cover Pages*/

.cover-clear{height:40px;}

.cover-1{
	padding:30px 40px 0px 40px;
	border-top:solid 1px rgba(255,255,255,0.1);
}

.cover-1, .cover-2, .cover-4, .cover-5{
	border-top:solid 1px rgba(255,255,255,0.1);
}

.cover-1 h1{
	font-size:30px;
	color:#FFFFFF;
}

.cover-1 h6{
	font-size:16px;
	color:#FFFFFF;
	padding:10px 0px 30px 0px;
	font-weight:300;
}

.cover-1 p{
	font-size:15px;
	font-weight:300;
	color:#a7a7a7;
	line-height:35px;
	margin-bottom:50px;
}

.cover-1 .button{
	border:solid 1px rgba(255,255,255,0.2);
	color:#FFFFFF;
	margin-right:10px;
}

.cover-2{padding-top:0px;}

.cover-2 h1{
	color:#FFFFFF;
	font-size:30px;
	font-weight:300;
	text-align:center;
	padding-top:30px;
}

.cover-2 h6{
	color:#c1c1c1;
	font-style: italic;
	font-size:13px;
	font-weight:300;
	text-align:center;
	padding:0px 0px 20px 0px;
}

.cover-2 p{
	font-size:15px;
	text-align:center;
	line-height:36px;
	color:#c1c1c1;
	padding:30px 35px 40px 35px;
	font-weight:300;
}

.cover-3{
	padding:20px 20px 20px 20px;
	background-color:#FFFFFF;
	margin:20px;
	border-radius:7px;
}

.cover-3 amp-img{
	margin:0 auto;
	display:block;
}

.cover-3 h1{
	font-size:24px;
	text-align:center;
	padding:20px 0px 0px 0px;
}

.cover-3 em{
	font-size:12px;
	display:block;
	text-align:center;
	margin-bottom:20px;
}

.cover-3 p{
	text-align:center;
	font-size:16px;
	font-weight:300;
	padding:0px 5px 0px 5px;
}

.cover-3 .socials{
	transform:scale(0.8, 0.8);
	width:210px;
	margin:0 auto;
}

.cover-3 .socials a{
	margin-left:4px;
	margin-right:4px;
}

.cover-4 h1{
	color:#FFFFFF;
	text-align:center;
	font-weight:300;
	font-size:36px;
	margin:30px 0px 10px 0px;
}

.cover-4 em{
	color:#FFFFFF;
	text-align:center;
	font-style:normal;
	display: block;
	font-size:12px;
	text-transform: uppercase;
	letter-spacing:1px;
	font-weight:300;
}

.cover-4 strong{
	color:#969696;
	text-transform:uppercase;
	font-weight:800;
	font-size:12px;
	text-align:center;
	display:block;
	margin:20px 0px 30px 0px;
}
.cover-4 strong i{
	padding-right:10px
}

.cover-4 p{
	padding:40px 30px 40px 30px;
	color:#FFFFFF;
	line-height:36px;
	text-align:center;
	font-weight:300;
	font-size:16px;
}

.cover-4 a{
	font-size:13px;
	width:170px;
	margin:0 auto;
}

.cover-5 h1{
	color:#FFFFFF;
	font-size:40px;
	font-weight:300;
	text-align:center;
	padding-top:30px;
}

.cover-5 em{
	display:block;
	text-align:center;
	color:#FFFFFF;
	font-size:12px;
	margin-top:10px;
	font-style: normal;
}

.cover-5 p{
	padding:20px 30px 20px 30px;
	color:#a7a7a7;
	font-weight:300;
	text-align:center;
	font-size:16px;
	line-height:40px;
}

.cover-socials a{
	width:35px;
	height:35px;
	border-radius:35px;
	float:left;
	text-align:center;
	line-height:35px;
	font-size:12px;
	margin:0px 5px 0px 5px;
}

.cover-socials{
	width:230px;
	margin:40px auto 30px auto;
}












</style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

<body>		
	<header>
		<a href="index.php" class="header-logo"></a>
		<a href="contact.php" class="header-icon-2"><i class="icon-14 fa fa-envelope-o"></i></a>
		<a href="button-amp.php" class="header-icon-1"><i class="icon-12 fa fa-chevron-left"></i></a>
	</header>
	
	<nav class="footer-5-icons">
		<a href="button-amp.php" class="active-item"><i class="icon-16 fa fa-bolt"></i><em>Features</em></a>
		<a href="button-pages.php"><i class="icon-16 fa fa-bookmark"></i><em>Pages</em></a>
		<a href="index.php"><i class="icon-18 fa fa-home"></i><em>Home</em></a>
		<a href="button-media.php"><i class="fa fa-picture-o"></i><em>Media</em></a>
		<a href="index-news.php"><i class="icon-16 fa fa-newspaper-o"></i><em>News</em></a>
	</nav>
	
	<div class="page-content">
		<div class="page-content-scroll">

			<div class="heading-block bg-1">
				<h4>Google Fonts</h4>
				<p>Provided by AMP</p>
				<div class="overlay"></div>
			</div>

			<div class="content">
				<h4>Using Fonts with AMP is simple</h4>
				<p>
					Simply import any font you like from Google fonts into your HTML file, and use it in the CSS.
					It's that easy! Just like any regular page. Below is an instant example. You can get over 800 fonts
					from <a href="https://fonts.google.com/">Google Fonts</a> for free!
				</p>
			</div>
			<div class="decoration decoration-margins"></div>

			<div class="heading-block bg-2">
				<h4>Font Awesome</h4>
				<p>Over 600 Icons Provided by AMP</p>
				<div class="overlay"></div>
			</div>

			<div class="content demo-icons">
				<a href="#web-application">
					<i class="fa fa-camera-retro fa-fw"></i>Web Application Icons
				</a>
				<a href="#accessibility">
					<i class="fa fa-universal-access fa-fw"></i> Accessibility Icons
				</a>
				<a href="#hand">
					<i class="fa fa-hand-spock-o fa-fw"></i>Hand Icons
				</a>
				<a href="#transportation">
					<i class="fa fa-ship fa-fw"></i>Transportation Icons
				</a>
				<a href="#gender">
					<i class="fa fa-venus fa-fw"></i>Gender Icons
				</a>
				<a href="#file-type">
					<i class="fa fa-file-image-o fa-fw"></i>File Type Icons
				</a>
				<a href="#spinner">
					<i class="fa fa-spinner fa-fw"></i>Spinner Icons
				</a>
				<a href="#form-control">
					<i class="fa fa-check-square fa-fw"></i>Form Control Icons
				</a>
				<a href="#payment">
					<i class="fa fa-credit-card fa-fw"></i>Payment Icons
				</a>
				<a href="#chart">
					<i class="fa fa-pie-chart fa-fw"></i>Chart Icons
				</a>
				<a href="#currency">
					<i class="fa fa-won fa-fw"></i>Currency Icons
				</a>
				<a href="#text-editor">
					<i class="fa fa-file-text-o fa-fw"></i>Text Editor Icons
				</a>
				<a href="#directional">
					<i class="fa fa-arrow-right fa-fw"></i>Directional Icons
				</a>
				<a href="#video-player">
					<i class="fa fa-play-circle fa-fw"></i>Video Player Icons
				</a>
				<a href="#brand">
					<i class="fa fa-facebook-official fa-fw"></i>Brand Icons
				</a>
				<a href="#medical">
					<i class="fa fa-medkit fa-fw"></i>Medical Icons
				</a>
				<a href="#address-book">
					<i class="fa fa-address-book"></i>address-book
				</a>
				<a href="#address-book-o">
					<i class="fa fa-address-book-o"></i>address-book-o
				</a>
				<a href="#address-card">
					<i class="fa fa-address-card"></i>address-card
				</a>
				<a href="#address-card-o">
					<i class="fa fa-address-card-o"></i>address-card-o
				</a>
				<a href="#bandcamp">
					<i class="fa fa-bandcamp"></i>bandcamp
				</a>
				<a href="#bath">
					<i class="fa fa-bath"></i>bath
				</a>
				<a href="#bath">
					<i class="fa fa-bathtub"></i>bathtub
				</a>
				<a href="#id-card">
					<i class="fa fa-drivers-license"></i>drivers-license
				</a>
				<a href="#id-card-o">
					<i class="fa fa-drivers-license-o"></i>drivers-license-o
				</a>
				<a href="#eercast">
					<i class="fa fa-eercast"></i>eercast
				</a>
				<a href="#envelope-open">
					<i class="fa fa-envelope-open"></i>envelope-open
				</a>
				<a href="#envelope-open-o">
					<i class="fa fa-envelope-open-o"></i>envelope-open-o
				</a>
				<a href="#etsy">
					<i class="fa fa-etsy"></i>etsy
				</a>
				<a href="#free-code-camp">
					<i class="fa fa-free-code-camp"></i>free-code-camp
				</a>
				<a href="#grav">
					<i class="fa fa-grav"></i>grav
				</a>
				<a href="#handshake-o">
					<i class="fa fa-handshake-o"></i>handshake-o
				</a>
				<a href="#id-badge">
					<i class="fa fa-id-badge"></i>id-badge
				</a>
				<a href="#id-card">
					<i class="fa fa-id-card"></i>id-card
				</a>
				<a href="#id-card-o">
					<i class="fa fa-id-card-o"></i>id-card-o
				</a>
				<a href="#imdb">
					<i class="fa fa-imdb"></i>imdb
				</a>
				<a href="#linode">
					<i class="fa fa-linode"></i>linode
				</a>
				<a href="#meetup">
					<i class="fa fa-meetup"></i>meetup
				</a>
				<a href="#microchip">
					<i class="fa fa-microchip"></i>microchip
				</a>
				<a href="#podcast">
					<i class="fa fa-podcast"></i>podcast
				</a>
				<a href="#quora">
					<i class="fa fa-quora"></i>quora
				</a>
				<a href="#ravelry">
					<i class="fa fa-ravelry"></i>ravelry
				</a>
				<a href="#bath">
					<i class="fa fa-s15"></i>s15
				</a>
				<a href="#shower">
					<i class="fa fa-shower"></i>shower
				</a>
				<a href="#snowflake-o">
					<i class="fa fa-snowflake-o"></i>snowflake-o
				</a>
				<a href="#superpowers">
					<i class="fa fa-superpowers"></i>superpowers
				</a>
				<a href="#telegram">
					<i class="fa fa-telegram"></i>telegram
				</a>
				<a href="#thermometer-full">
					<i class="fa fa-thermometer"></i>thermometer
				</a>
				<a href="#thermometer-empty">
					<i class="fa fa-thermometer-0"></i>thermometer-0
				</a>
				<a href="#thermometer-quarter">
					<i class="fa fa-thermometer-1"></i>thermometer-1
				</a>
				<a href="#thermometer-half">
					<i class="fa fa-thermometer-2"></i>thermometer-2
				</a>
				<a href="#thermometer-three-quarters">
					<i class="fa fa-thermometer-3"></i>thermometer-3
				</a>
				<a href="#thermometer-full">
					<i class="fa fa-thermometer-4"></i>thermometer-4
				</a>
				<a href="#thermometer-empty">
					<i class="fa fa-thermometer-empty"></i>thermometer-empty
				</a>
				<a href="#thermometer-full">
					<i class="fa fa-thermometer-full"></i>thermometer-full
				</a>
				<a href="#thermometer-half">
					<i class="fa fa-thermometer-half"></i>thermometer-half
				</a>
				<a href="#thermometer-quarter">
					<i class="fa fa-thermometer-quarter"></i>thermometer-quarter
				</a>
				<a href="#thermometer-three-quarters">
					<i class="fa fa-thermometer-three-quarters"></i>thermometer-three-quarters
				</a>
				<a href="#window-close">
					<i class="fa fa-times-rectangle"></i>times-rectangle
				</a>
				<a href="#window-close-o">
					<i class="fa fa-times-rectangle-o"></i>times-rectangle-o
				</a>
				<a href="#user-circle">
					<i class="fa fa-user-circle"></i>user-circle
				</a>
				<a href="#user-circle-o">
					<i class="fa fa-user-circle-o"></i>user-circle-o
				</a>
				<a href="#user-o">
					<i class="fa fa-user-o"></i>user-o
				</a>
				<a href="#address-card">
					<i class="fa fa-vcard"></i>vcard
				</a>
				<a href="#address-card-o">
					<i class="fa fa-vcard-o"></i>vcard-o
				</a>
				<a href="#window-close">
					<i class="fa fa-window-close"></i>window-close
				</a>
				<a href="#window-close-o">
					<i class="fa fa-window-close-o"></i>window-close-o
				</a>
				<a href="#window-maximize">
					<i class="fa fa-window-maximize"></i>window-maximize
				</a>
				<a href="#window-minimize">
					<i class="fa fa-window-minimize"></i>window-minimize
				</a>
				<a href="#window-restore">
					<i class="fa fa-window-restore"></i>window-restore
				</a>
				<a href="#wpexplorer">
					<i class="fa fa-wpexplorer"></i>wpexplorer
				</a>
				<a href="#address-book">
					<i class="fa fa-address-book"></i>address-book
				</a>
				<a href="#address-book-o">
					<i class="fa fa-address-book-o"></i>address-book-o
				</a>
				<a href="#address-card">
					<i class="fa fa-address-card"></i>address-card
				</a>
				<a href="#address-card-o">
					<i class="fa fa-address-card-o"></i>address-card-o
				</a>
				<a href="#adjust">
					<i class="fa fa-adjust"></i>	adjust
				</a>
				<a href="#american-sign-language-interpreting">
					<i class="fa fa-american-sign-language-interpreting"></i>american-sign-language-interpreting
				</a>
				<a href="#anchor">
					<i class="fa fa-anchor"></i>	anchor
				</a>
				<a href="#archive">
					<i class="fa fa-archive"></i>archive
				</a>
				<a href="#area-chart">
					<i class="fa fa-area-chart"></i>	area-chart
				</a>
				<a href="#arrows">
					<i class="fa fa-arrows"></i>	arrows
				</a>
				<a href="#arrows-h">
					<i class="fa fa-arrows-h"></i>arrows-h
				</a>
				<a href="#arrows-v">
					<i class="fa fa-arrows-v"></i>arrows-v
				</a>
				<a href="#american-sign-language-interpreting">
					<i class="fa fa-asl-interpreting"></i>asl-interpreting
				</a>
				<a href="#assistive-listening-systems">
					<i class="fa fa-assistive-listening-systems"></i>assistive-listening-systems
				</a>
				<a href="#asterisk">
					<i class="fa fa-asterisk"></i>asterisk
				</a>
				<a href="#at">
					<i class="fa fa-at"></i>at
				</a>
				<a href="#audio-description">
					<i class="fa fa-audio-description"></i>audio-description
				</a>
				<a href="#car">
					<i class="fa fa-automobile"></i>automobile
				</a>
				<a href="#balance-scale">
					<i class="fa fa-balance-scale"></i>balance-scale
				</a>
				<a href="#ban">
					<i class="fa fa-ban"></i>ban
				</a>
				<a href="#university">
					<i class="fa fa-bank"></i>bank
				</a>
				<a href="#bar-chart">
					<i class="fa fa-bar-chart"></i>bar-chart
				</a>
				<a href="#bar-chart">
					<i class="fa fa-bar-chart-o"></i>bar-chart-o
				</a>
				<a href="#barcode">
					<i class="fa fa-barcode"></i>barcode
				</a>
				<a href="#bars">
					<i class="fa fa-bars"></i>bars
				</a>
				<a href="#bath">
					<i class="fa fa-bath"></i>bath
				</a>
				<a href="#bath">
					<i class="fa fa-bathtub"></i>bathtub
				</a>
				<a href="#battery-full">
					<i class="fa fa-battery"></i>battery
				</a>
				<a href="#battery-empty">
					<i class="fa fa-battery-0"></i>battery-0

				</a>
				<a href="#battery-quarter">
					<i class="fa fa-battery-1"></i>battery-1

				</a>
				<a href="#battery-half">
					<i class="fa fa-battery-2"></i>battery-2

				</a>
				<a href="#battery-three-quarters">
					<i class="fa fa-battery-3"></i>battery-3

				</a>
				<a href="#battery-full">
					<i class="fa fa-battery-4"></i>battery-4
				</a>
				<a href="#battery-empty">
					<i class="fa fa-battery-empty"></i>battery-empty
				</a>
				<a href="#battery-full">
					<i class="fa fa-battery-full"></i>battery-full
				</a>
				<a href="#battery-half">
					<i class="fa fa-battery-half"></i>battery-half
				</a>
				<a href="#battery-quarter">
					<i class="fa fa-battery-quarter"></i>battery-quarter
				</a>
				<a href="#battery-three-quarters">
					<i class="fa fa-battery-three-quarters"></i>battery-three-quarters
				</a>
				<a href="#bed">
					<i class="fa fa-bed"></i>bed
				</a>
				<a href="#beer">
					<i class="fa fa-beer"></i>beer
				</a>
				<a href="#bell">
					<i class="fa fa-bell"></i>bell
				</a>
				<a href="#bell-o">
					<i class="fa fa-bell-o"></i>bell-o
				</a>
				<a href="#bell-slash">
					<i class="fa fa-bell-slash"></i>bell-slash
				</a>
				<a href="#bell-slash-o">
					<i class="fa fa-bell-slash-o"></i>bell-slash-o
				</a>
				<a href="#bicycle">
					<i class="fa fa-bicycle"></i>bicycle
				</a>
				<a href="#binoculars">
					<i class="fa fa-binoculars"></i>binoculars
				</a>
				<a href="#birthday-cake">
					<i class="fa fa-birthday-cake"></i>birthday-cake
				</a>
				<a href="#blind">
					<i class="fa fa-blind"></i>blind
				</a>
				<a href="#bluetooth">
					<i class="fa fa-bluetooth"></i>bluetooth
				</a>
				<a href="#bluetooth-b">
					<i class="fa fa-bluetooth-b"></i>bluetooth-b
				</a>
				<a href="#bolt">
					<i class="fa fa-bolt"></i>bolt
				</a>
				<a href="#bomb">
					<i class="fa fa-bomb"></i>bomb
				</a>
				<a href="#book">
					<i class="fa fa-book"></i>book
				</a>
				<a href="#bookmark">
					<i class="fa fa-bookmark"></i>bookmark
				</a>
				<a href="#bookmark-o">
					<i class="fa fa-bookmark-o"></i>bookmark-o
				</a>
				<a href="#braille">
					<i class="fa fa-braille"></i>braille
				</a>
				<a href="#briefcase">
					<i class="fa fa-briefcase"></i>briefcase
				</a>
				<a href="#bug">
					<i class="fa fa-bug"></i>bug
				</a>
				<a href="#building">
					<i class="fa fa-building"></i>building
				</a>
				<a href="#building-o">
					<i class="fa fa-building-o"></i>building-o
				</a>
				<a href="#bullhorn">
					<i class="fa fa-bullhorn"></i>bullhorn
				</a>
				<a href="#bullseye">
					<i class="fa fa-bullseye"></i>bullseye
				</a>
				<a href="#bus">
					<i class="fa fa-bus"></i>bus
				</a>
				<a href="#taxi">
					<i class="fa fa-cab"></i>cab
				</a>
				<a href="#calculator">
					<i class="fa fa-calculator"></i>calculator
				</a>
				<a href="#calendar">
					<i class="fa fa-calendar"></i>calendar
				</a>
				<a href="#calendar-check-o">
					<i class="fa fa-calendar-check-o"></i>calendar-check-o
				</a>
				<a href="#calendar-minus-o">
					<i class="fa fa-calendar-minus-o"></i>calendar-minus-o
				</a>
				<a href="#calendar-o">
					<i class="fa fa-calendar-o"></i>calendar-o
				</a>
				<a href="#calendar-plus-o">
					<i class="fa fa-calendar-plus-o"></i>calendar-plus-o
				</a>
				<a href="#calendar-times-o">
					<i class="fa fa-calendar-times-o"></i>calendar-times-o
				</a>
				<a href="#camera">
					<i class="fa fa-camera"></i>camera
				</a>
				<a href="#camera-retro">
					<i class="fa fa-camera-retro"></i>camera-retro
				</a>
				<a href="#car">
					<i class="fa fa-car"></i>car
				</a>
				<a href="#caret-square-o-down">
					<i class="fa fa-caret-square-o-down"></i>caret-square-o-down
				</a>
				<a href="#caret-square-o-left">
					<i class="fa fa-caret-square-o-left"></i>caret-square-o-left
				</a>
				<a href="#caret-square-o-right">
					<i class="fa fa-caret-square-o-right"></i>caret-square-o-right
				</a>
				<a href="#caret-square-o-up">
					<i class="fa fa-caret-square-o-up"></i>caret-square-o-up
				</a>
				<a href="#cart-arrow-down">
					<i class="fa fa-cart-arrow-down"></i>cart-arrow-down
				</a>
				<a href="#cart-plus">
					<i class="fa fa-cart-plus"></i>cart-plus
				</a>
				<a href="#cc">
					<i class="fa fa-cc"></i>cc
				</a>
				<a href="#certificate">
					<i class="fa fa-certificate"></i>certificate
				</a>
				<a href="#check">
					<i class="fa fa-check"></i>check
				</a>
				<a href="#check-circle">
					<i class="fa fa-check-circle"></i>check-circle
				</a>
				<a href="#check-circle-o">
					<i class="fa fa-check-circle-o"></i>check-circle-o
				</a>
				<a href="#check-square">
					<i class="fa fa-check-square"></i>check-square
				</a>
				<a href="#check-square-o">
					<i class="fa fa-check-square-o"></i>check-square-o
				</a>
				<a href="#child">
					<i class="fa fa-child"></i>child
				</a>
				<a href="#circle">
					<i class="fa fa-circle"></i>circle
				</a>
				<a href="#circle-o">
					<i class="fa fa-circle-o"></i>circle-o
				</a>
				<a href="#circle-o-notch">
					<i class="fa fa-circle-o-notch"></i>circle-o-notch
				</a>
				<a href="#circle-thin">
					<i class="fa fa-circle-thin"></i>circle-thin
				</a>
				<a href="#clock-o">
					<i class="fa fa-clock-o"></i>clock-o
				</a>
				<a href="#clone">
					<i class="fa fa-clone"></i>clone
				</a>
				<a href="#times">
					<i class="fa fa-close"></i>close

				</a>
				<a href="#cloud">
					<i class="fa fa-cloud"></i>cloud
				</a>
				<a href="#cloud-download">
					<i class="fa fa-cloud-download"></i>cloud-download
				</a>
				<a href="#cloud-upload">
					<i class="fa fa-cloud-upload"></i>cloud-upload
				</a>
				<a href="#code">
					<i class="fa fa-code"></i>code
				</a>
				<a href="#code-fork">
					<i class="fa fa-code-fork"></i>code-fork
				</a>
				<a href="#coffee">
					<i class="fa fa-coffee"></i>coffee
				</a>
				<a href="#cog">
					<i class="fa fa-cog"></i>cog
				</a>
				<a href="#cogs">
					<i class="fa fa-cogs"></i>cogs
				</a>
				<a href="#comment">
					<i class="fa fa-comment"></i>comment
				</a>
				<a href="#comment-o">
					<i class="fa fa-comment-o"></i>comment-o
				</a>
				<a href="#commenting">
					<i class="fa fa-commenting"></i>commenting
				</a>
				<a href="#commenting-o">
					<i class="fa fa-commenting-o"></i>commenting-o
				</a>
				<a href="#comments">
					<i class="fa fa-comments"></i>comments
				</a>
				<a href="#comments-o">
					<i class="fa fa-comments-o"></i>comments-o
				</a>
				<a href="#compass">
					<i class="fa fa-compass"></i>compass
				</a>
				<a href="#copyright">
					<i class="fa fa-copyright"></i>copyright
				</a>
				<a href="#creative-commons">
					<i class="fa fa-creative-commons"></i>creative-commons
				</a>
				<a href="#credit-card">
					<i class="fa fa-credit-card"></i>credit-card
				</a>
				<a href="#credit-card-alt">
					<i class="fa fa-credit-card-alt"></i>credit-card-alt
				</a>
				<a href="#crop">
					<i class="fa fa-crop"></i>crop
				</a>
				<a href="#crosshairs">
					<i class="fa fa-crosshairs"></i>crosshairs
				</a>
				<a href="#cube">
					<i class="fa fa-cube"></i>cube
				</a>
				<a href="#cubes">
					<i class="fa fa-cubes"></i>cubes
				</a>
				<a href="#cutlery">
					<i class="fa fa-cutlery"></i>cutlery
				</a>
				<a href="#tachometer">
					<i class="fa fa-dashboard"></i>dashboard
				</a>
				<a href="#database">
					<i class="fa fa-database"></i>database
				</a>
				<a href="#deaf">
					<i class="fa fa-deaf"></i>deaf
				</a>
				<a href="#deaf">
					<i class="fa fa-deafness"></i>deafness

				</a>
				<a href="#desktop">
					<i class="fa fa-desktop"></i>desktop
				</a>
				<a href="#diamond">
					<i class="fa fa-diamond"></i>diamond
				</a>
				<a href="#dot-circle-o">
					<i class="fa fa-dot-circle-o"></i>dot-circle-o
				</a>
				<a href="#download">
					<i class="fa fa-download"></i>download
				</a>
				<a href="#id-card">
					<i class="fa fa-drivers-license"></i>drivers-license

				</a>
				<a href="#id-card-o">
					<i class="fa fa-drivers-license-o"></i>drivers-license-o

				</a>
				<a href="#pencil-square-o">
					<i class="fa fa-edit"></i>edit

				</a>
				<a href="#ellipsis-h">
					<i class="fa fa-ellipsis-h"></i>ellipsis-h
				</a>
				<a href="#ellipsis-v">
					<i class="fa fa-ellipsis-v"></i>ellipsis-v
				</a>
				<a href="#envelope">
					<i class="fa fa-envelope"></i>envelope
				</a>
				<a href="#envelope-o">
					<i class="fa fa-envelope-o"></i>envelope-o
				</a>
				<a href="#envelope-open">
					<i class="fa fa-envelope-open"></i>envelope-open
				</a>
				<a href="#envelope-open-o">
					<i class="fa fa-envelope-open-o"></i>envelope-open-o
				</a>
				<a href="#envelope-square">
					<i class="fa fa-envelope-square"></i>envelope-square
				</a>
				<a href="#eraser">
					<i class="fa fa-eraser"></i>eraser
				</a>
				<a href="#exchange">
					<i class="fa fa-exchange"></i>exchange
				</a>
				<a href="#exclamation">
					<i class="fa fa-exclamation"></i>exclamation
				</a>
				<a href="#exclamation-circle">
					<i class="fa fa-exclamation-circle"></i>exclamation-circle
				</a>
				<a href="#exclamation-triangle">
					<i class="fa fa-exclamation-triangle"></i>exclamation-triangle
				</a>
				<a href="#external-link">
					<i class="fa fa-external-link"></i>external-link
				</a>
				<a href="#external-link-square">
					<i class="fa fa-external-link-square"></i>external-link-square
				</a>
				<a href="#eye">
					<i class="fa fa-eye"></i>eye
				</a>
				<a href="#eye-slash">
					<i class="fa fa-eye-slash"></i>eye-slash
				</a>
				<a href="#eyedropper">
					<i class="fa fa-eyedropper"></i>eyedropper
				</a>
				<a href="#fax">
					<i class="fa fa-fax"></i>fax
				</a>
				<a href="#rss">
					<i class="fa fa-feed"></i>feed
				</a>
				<a href="#female">
					<i class="fa fa-female"></i>female
				</a>
				<a href="#fighter-jet">
					<i class="fa fa-fighter-jet"></i>fighter-jet
				</a>
				<a href="#file-archive-o">
					<i class="fa fa-file-archive-o"></i>file-archive-o
				</a>
				<a href="#file-audio-o">
					<i class="fa fa-file-audio-o"></i>file-audio-o
				</a>
				<a href="#file-code-o">
					<i class="fa fa-file-code-o"></i>file-code-o
				</a>
				<a href="#file-excel-o">
					<i class="fa fa-file-excel-o"></i>file-excel-o
				</a>
				<a href="#file-image-o">
					<i class="fa fa-file-image-o"></i>file-image-o
				</a>
				<a href="#file-video-o">
					<i class="fa fa-file-movie-o"></i>file-movie-o
				</a>
				<a href="#file-pdf-o">
					<i class="fa fa-file-pdf-o"></i>file-pdf-o
				</a>
				<a href="#file-image-o">
					<i class="fa fa-file-photo-o"></i>file-photo-o
				</a>
				<a href="#file-image-o">
					<i class="fa fa-file-picture-o"></i>file-picture-o
				</a>
				<a href="#file-powerpoint-o">
					<i class="fa fa-file-powerpoint-o"></i>file-powerpoint-o
				</a>
				<a href="#file-audio-o">
					<i class="fa fa-file-sound-o"></i>file-sound-o
				</a>
				<a href="#file-video-o">
					<i class="fa fa-file-video-o"></i>file-video-o
				</a>
				<a href="#file-word-o">
					<i class="fa fa-file-word-o"></i>file-word-o
				</a>
				<a href="#file-archive-o">
					<i class="fa fa-file-zip-o"></i>file-zip-o
				</a>
				<a href="#film">
					<i class="fa fa-film"></i>film
				</a>
				<a href="#filter">
					<i class="fa fa-filter"></i>filter
				</a>
				<a href="#fire">
					<i class="fa fa-fire"></i>fire
				</a>
				<a href="#fire-extinguisher">
					<i class="fa fa-fire-extinguisher"></i>fire-extinguisher
				</a>
				<a href="#flag">
					<i class="fa fa-flag"></i>flag
				</a>
				<a href="#flag-checkered">
					<i class="fa fa-flag-checkered"></i>flag-checkered
				</a>
				<a href="#flag-o">
					<i class="fa fa-flag-o"></i>flag-o
				</a>
				<a href="#bolt">
					<i class="fa fa-flash"></i>flash
				</a>
				<a href="#flask">
					<i class="fa fa-flask"></i>flask
				</a>
				<a href="#folder">
					<i class="fa fa-folder"></i>folder
				</a>
				<a href="#folder-o">
					<i class="fa fa-folder-o"></i>folder-o
				</a>
				<a href="#folder-open">
					<i class="fa fa-folder-open"></i>folder-open
				</a>
				<a href="#folder-open-o">
					<i class="fa fa-folder-open-o"></i>folder-open-o
				</a>
				<a href="#frown-o">
					<i class="fa fa-frown-o"></i>frown-o
				</a>
				<a href="#futbol-o">
					<i class="fa fa-futbol-o"></i>futbol-o
				</a>
				<a href="#gamepad">
					<i class="fa fa-gamepad"></i>gamepad
				</a>
				<a href="#gavel">
					<i class="fa fa-gavel"></i>gavel
				</a>
				<a href="#cog">
					<i class="fa fa-gear"></i>gear
				</a>
				<a href="#cogs">
					<i class="fa fa-gears"></i>gears
				</a>
				<a href="#gift">
					<i class="fa fa-gift"></i>gift
				</a>
				<a href="#glass">
					<i class="fa fa-glass"></i>glass
				</a>
				<a href="#globe">
					<i class="fa fa-globe"></i>globe
				</a>
				<a href="#graduation-cap">
					<i class="fa fa-graduation-cap"></i>graduation-cap
				</a>
				<a href="#users">
					<i class="fa fa-group"></i>group
				</a>
				<a href="#hand-rock-o">
					<i class="fa fa-hand-grab-o"></i>hand-grab-o
				</a>
				<a href="#hand-lizard-o">
					<i class="fa fa-hand-lizard-o"></i>hand-lizard-o
				</a>
				<a href="#hand-paper-o">
					<i class="fa fa-hand-paper-o"></i>hand-paper-o
				</a>
				<a href="#hand-peace-o">
					<i class="fa fa-hand-peace-o"></i>hand-peace-o
				</a>
				<a href="#hand-pointer-o">
					<i class="fa fa-hand-pointer-o"></i>hand-pointer-o
				</a>
				<a href="#hand-rock-o">
					<i class="fa fa-hand-rock-o"></i>hand-rock-o
				</a>
				<a href="#hand-scissors-o">
					<i class="fa fa-hand-scissors-o"></i>hand-scissors-o
				</a>
				<a href="#hand-spock-o">
					<i class="fa fa-hand-spock-o"></i>hand-spock-o
				</a>
				<a href="#hand-paper-o">
					<i class="fa fa-hand-stop-o"></i>hand-stop-o
				</a>
				<a href="#handshake-o">
					<i class="fa fa-handshake-o"></i>handshake-o
				</a>
				<a href="#deaf">
					<i class="fa fa-hard-of-hearing"></i>hard-of-hearing
				</a>
				<a href="#hashtag">
					<i class="fa fa-hashtag"></i>hashtag
				</a>
				<a href="#hdd-o">
					<i class="fa fa-hdd-o"></i>hdd-o
				</a>
				<a href="#headphones">
					<i class="fa fa-headphones"></i>headphones
				</a>
				<a href="#heart">
					<i class="fa fa-heart"></i>heart
				</a>
				<a href="#heart-o">
					<i class="fa fa-heart-o"></i>heart-o
				</a>
				<a href="#heartbeat">
					<i class="fa fa-heartbeat"></i>heartbeat
				</a>
				<a href="#history">
					<i class="fa fa-history"></i>history
				</a>
				<a href="#home">
					<i class="fa fa-home"></i>home
				</a>
				<a href="#bed">
					<i class="fa fa-hotel"></i>hotel
				</a>
				<a href="#hourglass">
					<i class="fa fa-hourglass"></i>hourglass
				</a>
				<a href="#hourglass-start">
					<i class="fa fa-hourglass-1"></i>hourglass-1
				</a>
				<a href="#hourglass-half">
					<i class="fa fa-hourglass-2"></i>hourglass-2		
				</a>
				<a href="#hourglass-end">
					<i class="fa fa-hourglass-3"></i>hourglass-3		
				</a>
				<a href="#hourglass-end">
					<i class="fa fa-hourglass-end"></i>hourglass-end
				</a>
				<a href="#hourglass-half">
					<i class="fa fa-hourglass-half"></i>hourglass-half
				</a>
				<a href="#hourglass-o">
					<i class="fa fa-hourglass-o"></i>hourglass-o
				</a>
				<a href="#hourglass-start">
					<i class="fa fa-hourglass-start"></i>hourglass-start
				</a>
				<a href="#i-cursor">
					<i class="fa fa-i-cursor"></i>i-cursor
				</a>
				<a href="#id-badge">
					<i class="fa fa-id-badge"></i>id-badge
				</a>
				<a href="#id-card">
					<i class="fa fa-id-card"></i>id-card
				</a>
				<a href="#id-card-o">
					<i class="fa fa-id-card-o"></i>id-card-o
				</a>
				<a href="#picture-o">
					<i class="fa fa-image"></i>image
				</a>
				<a href="#inbox">
					<i class="fa fa-inbox"></i>inbox
				</a>
				<a href="#industry">
					<i class="fa fa-industry"></i>industry
				</a>
				<a href="#info">
					<i class="fa fa-info"></i>info
				</a>
				<a href="#info-circle">
					<i class="fa fa-info-circle"></i>info-circle
				</a>
				<a href="#university">
					<i class="fa fa-institution"></i>institution
				</a>
				<a href="#key">
					<i class="fa fa-key"></i>key
				</a>
				<a href="#keyboard-o">
					<i class="fa fa-keyboard-o"></i>keyboard-o
				</a>
				<a href="#language">
					<i class="fa fa-language"></i>language
				</a>
				<a href="#laptop">
					<i class="fa fa-laptop"></i>laptop
				</a>
				<a href="#leaf">
					<i class="fa fa-leaf"></i>leaf
				</a>
				<a href="#gavel">
					<i class="fa fa-legal"></i>legal
				</a>
				<a href="#lemon-o">
					<i class="fa fa-lemon-o"></i>lemon-o
				</a>
				<a href="#level-down">
					<i class="fa fa-level-down"></i>level-down
				</a>
				<a href="#level-up">
					<i class="fa fa-level-up"></i>level-up
				</a>
				<a href="#life-ring">
					<i class="fa fa-life-bouy"></i>life-bouy

				</a>
				<a href="#life-ring">
					<i class="fa fa-life-buoy"></i>life-buoy

				</a>
				<a href="#life-ring">
					<i class="fa fa-life-ring"></i>life-ring
				</a>
				<a href="#life-ring">
					<i class="fa fa-life-saver"></i>life-saver
				</a>
				<a href="#lightbulb-o">
					<i class="fa fa-lightbulb-o"></i>lightbulb-o
				</a>
				<a href="#line-chart">
					<i class="fa fa-line-chart"></i>line-chart
				</a>
				<a href="#location-arrow">
					<i class="fa fa-location-arrow"></i>location-arrow
				</a>
				<a href="#lock">
					<i class="fa fa-lock"></i>lock
				</a>
				<a href="#low-vision">
					<i class="fa fa-low-vision"></i>low-vision
				</a>
				<a href="#magic">
					<i class="fa fa-magic"></i>magic
				</a>
				<a href="#magnet">
					<i class="fa fa-magnet"></i>magnet
				</a>
				<a href="#share">
					<i class="fa fa-mail-forward"></i>mail-forward
				</a>
				<a href="#reply">
					<i class="fa fa-mail-reply"></i>mail-reply
				</a>
				<a href="#reply-all">
					<i class="fa fa-mail-reply-all"></i>mail-reply-all
				</a>
				<a href="#male">
					<i class="fa fa-male"></i>male
				</a>
				<a href="#map">
					<i class="fa fa-map"></i>map
				</a>
				<a href="#map-marker">
					<i class="fa fa-map-marker"></i>map-marker
				</a>
				<a href="#map-o">
					<i class="fa fa-map-o"></i>map-o
				</a>
				<a href="#map-pin">
					<i class="fa fa-map-pin"></i>map-pin
				</a>
				<a href="#map-signs">
					<i class="fa fa-map-signs"></i>map-signs
				</a>
				<a href="#meh-o">
					<i class="fa fa-meh-o"></i>meh-o
				</a>
				<a href="#microchip">
					<i class="fa fa-microchip"></i>microchip
				</a>
				<a href="#microphone">
					<i class="fa fa-microphone"></i>microphone
				</a>
				<a href="#microphone-slash">
					<i class="fa fa-microphone-slash"></i>microphone-slash
				</a>
				<a href="#minus">
					<i class="fa fa-minus"></i>minus
				</a>
				<a href="#minus-circle">
					<i class="fa fa-minus-circle"></i>minus-circle
				</a>
				<a href="#minus-square">
					<i class="fa fa-minus-square"></i>minus-square
				</a>
				<a href="#minus-square-o">
					<i class="fa fa-minus-square-o"></i>minus-square-o
				</a>
				<a href="#mobile">
					<i class="fa fa-mobile"></i>mobile
				</a>
				<a href="#mobile">
					<i class="fa fa-mobile-phone"></i>mobile-phone
				</a>
				<a href="#money">
					<i class="fa fa-money"></i>money
				</a>
				<a href="#moon-o">
					<i class="fa fa-moon-o"></i>moon-o
				</a>
				<a href="#graduation-cap">
					<i class="fa fa-mortar-board"></i>mortar-board
				</a>
				<a href="#motorcycle">
					<i class="fa fa-motorcycle"></i>motorcycle
				</a>
				<a href="#mouse-pointer">
					<i class="fa fa-mouse-pointer"></i>mouse-pointer
				</a>
				<a href="#music">
					<i class="fa fa-music"></i>music
				</a>
				<a href="#bars">
					<i class="fa fa-navicon"></i>navicon
				</a>
				<a href="#newspaper-o">
					<i class="fa fa-newspaper-o"></i>newspaper-o
				</a>
				<a href="#object-group">
					<i class="fa fa-object-group"></i>object-group
				</a>
				<a href="#object-ungroup">
					<i class="fa fa-object-ungroup"></i>object-ungroup
				</a>
				<a href="#paint-brush">
					<i class="fa fa-paint-brush"></i>paint-brush
				</a>
				<a href="#paper-plane">
					<i class="fa fa-paper-plane"></i>paper-plane
				</a>
				<a href="#paper-plane-o">
					<i class="fa fa-paper-plane-o"></i>paper-plane-o
				</a>
				<a href="#paw">
					<i class="fa fa-paw"></i>paw
				</a>
				<a href="#pencil">
					<i class="fa fa-pencil"></i>pencil
				</a>
				<a href="#pencil-square">
					<i class="fa fa-pencil-square"></i>pencil-square
				</a>
				<a href="#pencil-square-o">
					<i class="fa fa-pencil-square-o"></i>pencil-square-o
				</a>
				<a href="#percent">
					<i class="fa fa-percent"></i>percent
				</a>
				<a href="#phone">
					<i class="fa fa-phone"></i>phone
				</a>
				<a href="#phone-square">
					<i class="fa fa-phone-square"></i>phone-square
				</a>
				<a href="#picture-o">
					<i class="fa fa-photo"></i>photo
				</a>
				<a href="#picture-o">
					<i class="fa fa-picture-o"></i>picture-o
				</a>
				<a href="#pie-chart">
					<i class="fa fa-pie-chart"></i>pie-chart
				</a>
				<a href="#plane">
					<i class="fa fa-plane"></i>plane
				</a>
				<a href="#plug">
					<i class="fa fa-plug"></i>plug
				</a>
				<a href="#plus">
					<i class="fa fa-plus"></i>plus
				</a>
				<a href="#plus-circle">
					<i class="fa fa-plus-circle"></i>plus-circle
				</a>
				<a href="#plus-square">
					<i class="fa fa-plus-square"></i>plus-square
				</a>
				<a href="#plus-square-o">
					<i class="fa fa-plus-square-o"></i>plus-square-o
				</a>
				<a href="#podcast">
					<i class="fa fa-podcast"></i>podcast
				</a>
				<a href="#power-off">
					<i class="fa fa-power-off"></i>power-off
				</a>
				<a href="#print">
					<i class="fa fa-print"></i>print
				</a>
				<a href="#puzzle-piece">
					<i class="fa fa-puzzle-piece"></i>puzzle-piece
				</a>
				<a href="#qrcode">
					<i class="fa fa-qrcode"></i>qrcode
				</a>
				<a href="#question">
					<i class="fa fa-question"></i>question
				</a>
				<a href="#question-circle">
					<i class="fa fa-question-circle"></i>question-circle
				</a>
				<a href="#question-circle-o">
					<i class="fa fa-question-circle-o"></i>question-circle-o
				</a>
				<a href="#quote-left">
					<i class="fa fa-quote-left"></i>quote-left
				</a>
				<a href="#quote-right">
					<i class="fa fa-quote-right"></i>quote-right
				</a>
				<a href="#random">
					<i class="fa fa-random"></i>random
				</a>
				<a href="#recycle">
					<i class="fa fa-recycle"></i>recycle
				</a>
				<a href="#refresh">
					<i class="fa fa-refresh"></i>refresh
				</a>
				<a href="#registered">
					<i class="fa fa-registered"></i>registered
				</a>
				<a href="#times">
					<i class="fa fa-remove"></i>remove
				</a>
				<a href="#bars">
					<i class="fa fa-reorder"></i>reorder
				</a>
				<a href="#reply">
					<i class="fa fa-reply"></i>reply
				</a>
				<a href="#reply-all">
					<i class="fa fa-reply-all"></i>reply-all
				</a>
				<a href="#retweet">
					<i class="fa fa-retweet"></i>retweet
				</a>
				<a href="#road">
					<i class="fa fa-road"></i>road
				</a>
				<a href="#rocket">
					<i class="fa fa-rocket"></i>rocket
				</a>
				<a href="#rss">
					<i class="fa fa-rss"></i>rss
				</a>
				<a href="#rss-square">
					<i class="fa fa-rss-square"></i>rss-square
				</a>
				<a href="#bath">
					<i class="fa fa-s15"></i>s15
				</a>
				<a href="#search">
					<i class="fa fa-search"></i>search
				</a>
				<a href="#search-minus">
					<i class="fa fa-search-minus"></i>search-minus
				</a>
				<a href="#search-plus">
					<i class="fa fa-search-plus"></i>search-plus
				</a>
				<a href="#paper-plane">
					<i class="fa fa-send"></i>send
				</a>
				<a href="#paper-plane-o">
					<i class="fa fa-send-o"></i>send-o
				</a>
				<a href="#server">
					<i class="fa fa-server"></i>server
				</a>
				<a href="#share">
					<i class="fa fa-share"></i>share
				</a>
				<a href="#share-alt">
					<i class="fa fa-share-alt"></i>share-alt
				</a>
				<a href="#share-alt-square">
					<i class="fa fa-share-alt-square"></i>share-alt-square
				</a>
				<a href="#share-square">
					<i class="fa fa-share-square"></i>share-square
				</a>
				<a href="#share-square-o">
					<i class="fa fa-share-square-o"></i>share-square-o
				</a>
				<a href="#shield">
					<i class="fa fa-shield"></i>shield
				</a>
				<a href="#ship">
					<i class="fa fa-ship"></i>ship
				</a>
				<a href="#shopping-bag">
					<i class="fa fa-shopping-bag"></i>shopping-bag
				</a>
				<a href="#shopping-basket">
					<i class="fa fa-shopping-basket"></i>shopping-basket
				</a>
				<a href="#shopping-cart">
					<i class="fa fa-shopping-cart"></i>shopping-cart
				</a>
				<a href="#shower">
					<i class="fa fa-shower"></i>shower
				</a>
				<a href="#sign-in">
					<i class="fa fa-sign-in"></i>sign-in
				</a>
				<a href="#sign-language">
					<i class="fa fa-sign-language"></i>sign-language
				</a>
				<a href="#sign-out">
					<i class="fa fa-sign-out"></i>sign-out
				</a>
				<a href="#signal">
					<i class="fa fa-signal"></i>signal
				</a>
				<a href="#sign-language">
					<i class="fa fa-signing"></i>signing
				</a>
				<a href="#sitemap">
					<i class="fa fa-sitemap"></i>sitemap
				</a>
				<a href="#sliders">
					<i class="fa fa-sliders"></i>sliders
				</a>
				<a href="#smile-o">
					<i class="fa fa-smile-o"></i>smile-o
				</a>
				<a href="#snowflake-o">
					<i class="fa fa-snowflake-o"></i>snowflake-o
				</a>
				<a href="#futbol-o">
					<i class="fa fa-soccer-ball-o"></i>soccer-ball-o
				</a>
				<a href="#sort">
					<i class="fa fa-sort"></i>sort
				</a>
				<a href="#sort-alpha-asc">
					<i class="fa fa-sort-alpha-asc"></i>sort-alpha-asc
				</a>
				<a href="#sort-alpha-desc">
					<i class="fa fa-sort-alpha-desc"></i>sort-alpha-desc
				</a>
				<a href="#sort-amount-asc">
					<i class="fa fa-sort-amount-asc"></i>sort-amount-asc
				</a>
				<a href="#sort-amount-desc">
					<i class="fa fa-sort-amount-desc"></i>sort-amount-desc
				</a>
				<a href="#sort-asc">
					<i class="fa fa-sort-asc"></i>sort-asc
				</a>
				<a href="#sort-desc">
					<i class="fa fa-sort-desc"></i>sort-desc
				</a>
				<a href="#sort-desc">
					<i class="fa fa-sort-down"></i>sort-down
				</a>
				<a href="#sort-numeric-asc">
					<i class="fa fa-sort-numeric-asc"></i>sort-numeric-asc
				</a>
				<a href="#sort-numeric-desc">
					<i class="fa fa-sort-numeric-desc"></i>sort-numeric-desc
				</a>
				<a href="#sort-asc">
					<i class="fa fa-sort-up"></i>sort-up
				</a>
				<a href="#space-shuttle">
					<i class="fa fa-space-shuttle"></i>space-shuttle
				</a>
				<a href="#spinner">
					<i class="fa fa-spinner"></i>spinner
				</a>
				<a href="#spoon">
					<i class="fa fa-spoon"></i>spoon
				</a>
				<a href="#square">
					<i class="fa fa-square"></i>square
				</a>
				<a href="#square-o">
					<i class="fa fa-square-o"></i>square-o
				</a>
				<a href="#star">
					<i class="fa fa-star"></i>star
				</a>
				<a href="#star-half">
					<i class="fa fa-star-half"></i>star-half
				</a>
				<a href="#star-half-o">
					<i class="fa fa-star-half-empty"></i>star-half-empty
				</a>
				<a href="#star-half-o">
					<i class="fa fa-star-half-full"></i>star-half-full
				</a>
				<a href="#star-half-o">
					<i class="fa fa-star-half-o"></i>star-half-o
				</a>
				<a href="#star-o">
					<i class="fa fa-star-o"></i>star-o
				</a>
				<a href="#sticky-note">
					<i class="fa fa-sticky-note"></i>sticky-note
				</a>
				<a href="#sticky-note-o">
					<i class="fa fa-sticky-note-o"></i>sticky-note-o
				</a>
				<a href="#street-view">
					<i class="fa fa-street-view"></i>street-view
				</a>
				<a href="#suitcase">
					<i class="fa fa-suitcase"></i>suitcase
				</a>
				<a href="#sun-o">
					<i class="fa fa-sun-o"></i>sun-o
				</a>
				<a href="#life-ring">
					<i class="fa fa-support"></i>support
				</a>
				<a href="#tablet">
					<i class="fa fa-tablet"></i>tablet
				</a>
				<a href="#tachometer">
					<i class="fa fa-tachometer"></i>tachometer
				</a>
				<a href="#tag">
					<i class="fa fa-tag"></i>tag
				</a>
				<a href="#tags">
					<i class="fa fa-tags"></i>tags
				</a>
				<a href="#tasks">
					<i class="fa fa-tasks"></i>tasks
				</a>
				<a href="#taxi">
					<i class="fa fa-taxi"></i>taxi
				</a>
				<a href="#television">
					<i class="fa fa-television"></i>television
				</a>
				<a href="#terminal">
					<i class="fa fa-terminal"></i>terminal
				</a>
				<a href="#thermometer-full">
					<i class="fa fa-thermometer"></i>thermometer
				</a>
				<a href="#thermometer-empty">
					<i class="fa fa-thermometer-0"></i>thermometer-0
				</a>
				<a href="#thermometer-quarter">
					<i class="fa fa-thermometer-1"></i>thermometer-1
				</a>
				<a href="#thermometer-half">
					<i class="fa fa-thermometer-2"></i>thermometer-2
				</a>
				<a href="#thermometer-three-quarters">
					<i class="fa fa-thermometer-3"></i>thermometer-3
				</a>
				<a href="#thermometer-full">
					<i class="fa fa-thermometer-4"></i>thermometer-4
				</a>
				<a href="#thermometer-empty">
					<i class="fa fa-thermometer-empty"></i>thermometer-empty
				</a>
				<a href="#thermometer-full">
					<i class="fa fa-thermometer-full"></i>thermometer-full
				</a>
				<a href="#thermometer-half">
					<i class="fa fa-thermometer-half"></i>thermometer-half
				</a>
				<a href="#thermometer-quarter">
					<i class="fa fa-thermometer-quarter"></i>thermometer-quarter
				</a>
				<a href="#thermometer-three-quarters">
					<i class="fa fa-thermometer-three-quarters"></i>thermometer-three-quarters
				</a>
				<a href="#thumb-tack">
					<i class="fa fa-thumb-tack"></i>thumb-tack
				</a>
				<a href="#thumbs-down">
					<i class="fa fa-thumbs-down"></i>thumbs-down
				</a>
				<a href="#thumbs-o-down">
					<i class="fa fa-thumbs-o-down"></i>thumbs-o-down
				</a>
				<a href="#thumbs-o-up">
					<i class="fa fa-thumbs-o-up"></i>thumbs-o-up
				</a>
				<a href="#thumbs-up">
					<i class="fa fa-thumbs-up"></i>thumbs-up
				</a>
				<a href="#ticket">
					<i class="fa fa-ticket"></i>ticket
				</a>
				<a href="#times">
					<i class="fa fa-times"></i>times
				</a>
				<a href="#times-circle">
					<i class="fa fa-times-circle"></i>times-circle
				</a>
				<a href="#times-circle-o">
					<i class="fa fa-times-circle-o"></i>times-circle-o
				</a>
				<a href="#window-close">
					<i class="fa fa-times-rectangle"></i>times-rectangle
				</a>
				<a href="#window-close-o">
					<i class="fa fa-times-rectangle-o"></i>times-rectangle-o
				</a>
				<a href="#tint">
					<i class="fa fa-tint"></i>tint
				</a>
				<a href="#caret-square-o-down">
					<i class="fa fa-toggle-down"></i>toggle-down
				</a>
				<a href="#caret-square-o-left">
					<i class="fa fa-toggle-left"></i>toggle-left
				</a>
				<a href="#toggle-off">
					<i class="fa fa-toggle-off"></i>	toggle-off
				</a>
				<a href="#toggle-on">
					<i class="fa fa-toggle-on"></i>toggle-on
				</a>
				<a href="#caret-square-o-right">
					<i class="fa fa-toggle-right"></i>toggle-right
				</a>
				<a href="#caret-square-o-up">
					<i class="fa fa-toggle-up"></i>toggle-up
				</a>
				<a href="#trademark">
					<i class="fa fa-trademark"></i>trademark
				</a>
				<a href="#trash">
					<i class="fa fa-trash"></i>trash
				</a>
				<a href="#trash-o">
					<i class="fa fa-trash-o"></i>trash-o
				</a>
				<a href="#tree">
					<i class="fa fa-tree"></i>tree
				</a>
				<a href="#trophy">
					<i class="fa fa-trophy"></i>trophy
				</a>
				<a href="#truck">
					<i class="fa fa-truck"></i>truck
				</a>
				<a href="#tty">
					<i class="fa fa-tty"></i>tty
				</a>
				<a href="#television">
					<i class="fa fa-tv"></i>tv
				</a>
				<a href="#umbrella">
					<i class="fa fa-umbrella"></i>umbrella
				</a>
				<a href="#universal-access">
					<i class="fa fa-universal-access"></i>universal-access
				</a>
				<a href="#university">
					<i class="fa fa-university"></i>university
				</a>
				<a href="#unlock">
					<i class="fa fa-unlock"></i>unlock
				</a>
				<a href="#unlock-alt">
					<i class="fa fa-unlock-alt"></i>	unlock-alt
				</a>
				<a href="#sort">
					<i class="fa fa-unsorted"></i>unsorted

				</a>
				<a href="#upload">
					<i class="fa fa-upload"></i>upload
				</a>
				<a href="#user">
					<i class="fa fa-user"></i>user
				</a>
				<a href="#user-circle">
					<i class="fa fa-user-circle"></i>user-circle
				</a>
				<a href="#user-circle-o">
					<i class="fa fa-user-circle-o"></i>user-circle-o
				</a>
				<a href="#user-o">
					<i class="fa fa-user-o"></i>user-o
				</a>
				<a href="#user-plus">
					<i class="fa fa-user-plus"></i>user-plus
				</a>
				<a href="#user-secret">
					<i class="fa fa-user-secret"></i>user-secret
				</a>
				<a href="#user-times">
					<i class="fa fa-user-times"></i>user-times
				</a>
				<a href="#users">
					<i class="fa fa-users"></i>users
				</a>
				<a href="#address-card">
					<i class="fa fa-vcard"></i>vcard
				</a>
				<a href="#address-card-o">
					<i class="fa fa-vcard-o"></i>vcard-o
				</a>
				<a href="#video-camera">
					<i class="fa fa-video-camera"></i>video-camera
				</a>
				<a href="#volume-control-phone">
					<i class="fa fa-volume-control-phone"></i>volume-control-phone
				</a>
				<a href="#volume-down">
					<i class="fa fa-volume-down"></i>volume-down
				</a>
				<a href="#volume-off">
					<i class="fa fa-volume-off"></i>volume-off
				</a>
				<a href="#volume-up">
					<i class="fa fa-volume-up"></i>volume-up
				</a>
				<a href="#exclamation-triangle">
					<i class="fa fa-warning"></i>warning
				</a>
				<a href="#wheelchair">
					<i class="fa fa-wheelchair"></i>wheelchair
				</a>
				<a href="#wheelchair-alt">
					<i class="fa fa-wheelchair-alt"></i>wheelchair-alt
				</a>
				<a href="#wifi">
					<i class="fa fa-wifi"></i>wifi
				</a>
				<a href="#window-close">
					<i class="fa fa-window-close"></i>window-close
				</a>
				<a href="#window-close-o">
					<i class="fa fa-window-close-o"></i>window-close-o
				</a>
				<a href="#window-maximize">
					<i class="fa fa-window-maximize"></i>window-maximize
				</a>
				<a href="#window-minimize">
					<i class="fa fa-window-minimize"></i>window-minimize
				</a>
				<a href="#window-restore">
					<i class="fa fa-window-restore"></i>window-restore
				</a>
				<a href="#wrench">
					<i class="fa fa-wrench"></i>wrench
				</a>
				<a href="#american-sign-language-interpreting">
					<i class="fa fa-american-sign-language-interpreting"></i>american-sign-language-interpreting
				</a>
				<a href="#american-sign-language-interpreting">
					<i class="fa fa-asl-interpreting"></i>asl-interpreting

				</a>
				<a href="#assistive-listening-systems">
					<i class="fa fa-assistive-listening-systems"></i>assistive-listening-systems
				</a>
				<a href="#audio-description">
					<i class="fa fa-audio-description"></i>audio-description
				</a>
				<a href="#blind">
					<i class="fa fa-blind"></i>blind
				</a>
				<a href="#braille">
					<i class="fa fa-braille"></i>braille
				</a>
				<a href="#cc">
					<i class="fa fa-cc"></i>cc
				</a>
				<a href="#deaf">
					<i class="fa fa-deaf"></i>deaf
				</a>
				<a href="#deaf">
					<i class="fa fa-deafness"></i>deafness
				</a>
				<a href="#deaf">
					<i class="fa fa-hard-of-hearing"></i>hard-of-hearing
				</a>
				<a href="#low-vision">
					<i class="fa fa-low-vision"></i>low-vision
				</a>
				<a href="#question-circle-o">
					<i class="fa fa-question-circle-o"></i>question-circle-o
				</a>
				<a href="#sign-language">
					<i class="fa fa-sign-language"></i>sign-language
				</a>
				<a href="#sign-language">
					<i class="fa fa-signing"></i>signing
				</a>
				<a href="#tty">
					<i class="fa fa-tty"></i>tty
				</a>
				<a href="#universal-access">
					<i class="fa fa-universal-access"></i>universal-access
				</a>
				<a href="#volume-control-phone">
					<i class="fa fa-volume-control-phone"></i>volume-control-phone
				</a>
				<a href="#wheelchair">
					<i class="fa fa-wheelchair"></i>wheelchair
				</a>
				<a href="#wheelchair-alt">
					<i class="fa fa-wheelchair-alt"></i>wheelchair-alt
				</a>
				<a href="#hand-rock-o">
					<i class="fa fa-hand-grab-o"></i>hand-grab-o
				</a>
				<a href="#hand-lizard-o">
					<i class="fa fa-hand-lizard-o"></i>hand-lizard-o
				</a>
				<a href="#hand-o-down">
					<i class="fa fa-hand-o-down"></i>hand-o-down
				</a>
				<a href="#hand-o-left">
					<i class="fa fa-hand-o-left"></i>hand-o-left
				</a>
				<a href="#hand-o-right">
					<i class="fa fa-hand-o-right"></i>hand-o-right
				</a>
				<a href="#hand-o-up">
					<i class="fa fa-hand-o-up"></i>hand-o-up
				</a>
				<a href="#hand-paper-o">
					<i class="fa fa-hand-paper-o"></i>hand-paper-o
				</a>
				<a href="#hand-peace-o">
					<i class="fa fa-hand-peace-o"></i>hand-peace-o
				</a>
				<a href="#hand-pointer-o">
					<i class="fa fa-hand-pointer-o"></i>hand-pointer-o
				</a>
				<a href="#hand-rock-o">
					<i class="fa fa-hand-rock-o"></i>hand-rock-o
				</a>
				<a href="#hand-scissors-o">
					<i class="fa fa-hand-scissors-o"></i>hand-scissors-o
				</a>
				<a href="#hand-spock-o">
					<i class="fa fa-hand-spock-o"></i>hand-spock-o
				</a>
				<a href="#hand-paper-o">
					<i class="fa fa-hand-stop-o"></i>hand-stop-o
				</a>
				<a href="#thumbs-down">
					<i class="fa fa-thumbs-down"></i>thumbs-down
				</a>
				<a href="#thumbs-o-down">
					<i class="fa fa-thumbs-o-down"></i>thumbs-o-down
				</a>
				<a href="#thumbs-o-up">
					<i class="fa fa-thumbs-o-up"></i>thumbs-o-up
				</a>
				<a href="#thumbs-up">
					<i class="fa fa-thumbs-up"></i>thumbs-up
				</a>
				<a href="#ambulance">
					<i class="fa fa-ambulance"></i>ambulance
				</a>
				<a href="#car">
					<i class="fa fa-automobile"></i>automobile
				</a>
				<a href="#bicycle">
					<i class="fa fa-bicycle"></i>bicycle
				</a>
				<a href="#bus">
					<i class="fa fa-bus"></i>bus
				</a>
				<a href="#taxi">
					<i class="fa fa-cab"></i>cab
				</a>
				<a href="#car">
					<i class="fa fa-car"></i>car
				</a>
				<a href="#fighter-jet">
					<i class="fa fa-fighter-jet"></i>fighter-jet
				</a>
				<a href="#motorcycle">
					<i class="fa fa-motorcycle"></i>motorcycle
				</a>
				<a href="#plane">
					<i class="fa fa-plane"></i>plane
				</a>
				<a href="#rocket">
					<i class="fa fa-rocket"></i>rocket
				</a>
				<a href="#ship">
					<i class="fa fa-ship"></i>ship
				</a>
				<a href="#space-shuttle">
					<i class="fa fa-space-shuttle"></i>space-shuttle
				</a>
				<a href="#subway">
					<i class="fa fa-subway"></i>subway
				</a>
				<a href="#taxi">
					<i class="fa fa-taxi"></i>taxi
				</a>
				<a href="#train">
					<i class="fa fa-train"></i>train
				</a>
				<a href="#truck">
					<i class="fa fa-truck"></i>truck
				</a>
				<a href="#wheelchair">
					<i class="fa fa-wheelchair"></i>wheelchair
				</a>
				<a href="#wheelchair-alt">
					<i class="fa fa-wheelchair-alt"></i>wheelchair-alt
				</a>
				<a href="#genderless">
					<i class="fa fa-genderless"></i>genderless
				</a>
				<a href="#transgender">
					<i class="fa fa-intersex"></i>intersex

				</a>
				<a href="#mars">
					<i class="fa fa-mars"></i>mars
				</a>
				<a href="#mars-double">
					<i class="fa fa-mars-double"></i>mars-double
				</a>
				<a href="#mars-stroke">
					<i class="fa fa-mars-stroke"></i>mars-stroke
				</a>
				<a href="#mars-stroke-h">
					<i class="fa fa-mars-stroke-h"></i>mars-stroke-h
				</a>
				<a href="#mars-stroke-v">
					<i class="fa fa-mars-stroke-v"></i>mars-stroke-v
				</a>
				<a href="#mercury">
					<i class="fa fa-mercury"></i>mercury
				</a>
				<a href="#neuter">
					<i class="fa fa-neuter"></i>neuter
				</a>
				<a href="#transgender">
					<i class="fa fa-transgender"></i>transgender
				</a>
				<a href="#transgender-alt">
					<i class="fa fa-transgender-alt"></i>transgender-alt
				</a>
				<a href="#venus">
					<i class="fa fa-venus"></i>venus
				</a>
				<a href="#venus-double">
					<i class="fa fa-venus-double"></i>venus-double
				</a>
				<a href="#venus-mars">
					<i class="fa fa-venus-mars"></i>venus-mars
				</a>
				<a href="#file">
					<i class="fa fa-file"></i>file
				</a>
				<a href="#file-archive-o">
					<i class="fa fa-file-archive-o"></i>file-archive-o
				</a>
				<a href="#file-audio-o">
					<i class="fa fa-file-audio-o"></i>file-audio-o
				</a>
				<a href="#file-code-o">
					<i class="fa fa-file-code-o"></i>file-code-o
				</a>
				<a href="#file-excel-o">
					<i class="fa fa-file-excel-o"></i>file-excel-o
				</a>
				<a href="#file-image-o">
					<i class="fa fa-file-image-o"></i>file-image-o
				</a>
				<a href="#file-video-o">
					<i class="fa fa-file-movie-o"></i>file-movie-o
				</a>
				<a href="#file-o">
					<i class="fa fa-file-o"></i>file-o
				</a>
				<a href="#file-pdf-o">
					<i class="fa fa-file-pdf-o"></i>file-pdf-o
				</a>
				<a href="#file-image-o">
					<i class="fa fa-file-photo-o"></i>file-photo-o
				</a>
				<a href="#file-image-o">
					<i class="fa fa-file-picture-o"></i>file-picture-o
				</a>
				<a href="#file-powerpoint-o">
					<i class="fa fa-file-powerpoint-o"></i>file-powerpoint-o
				</a>
				<a href="#file-audio-o">
					<i class="fa fa-file-sound-o"></i>file-sound-o

				</a>
				<a href="#file-text">
					<i class="fa fa-file-text"></i>file-text
				</a>
				<a href="#file-text-o">
					<i class="fa fa-file-text-o"></i>file-text-o
				</a>
				<a href="#file-video-o">
					<i class="fa fa-file-video-o"></i>file-video-o
				</a>
				<a href="#file-word-o">
					<i class="fa fa-file-word-o"></i>file-word-o
				</a>
				<a href="#file-archive-o">
					<i class="fa fa-file-zip-o"></i>file-zip-o
				</a>
				<a href="#circle-o-notch">
					<i class="fa fa-circle-o-notch"></i>circle-o-notch
				</a>
				<a href="#cog">
					<i class="fa fa-cog"></i>cog
				</a>
				<a href="#cog">
					<i class="fa fa-gear"></i>gear
				</a>
				<a href="#refresh">
					<i class="fa fa-refresh"></i>refresh
				</a>
				<a href="#spinner">
					<i class="fa fa-spinner"></i>spinner
				</a>
				<a href="#check-square">
					<i class="fa fa-check-square"></i>check-square
				</a>
				<a href="#check-square-o">
					<i class="fa fa-check-square-o"></i>check-square-o
				</a>
				<a href="#circle">
					<i class="fa fa-circle"></i>circle
				</a>
				<a href="#circle-o">
					<i class="fa fa-circle-o"></i>circle-o
				</a>
				<a href="#dot-circle-o">
					<i class="fa fa-dot-circle-o"></i>dot-circle-o
				</a>
				<a href="#minus-square">
					<i class="fa fa-minus-square"></i>minus-square
				</a>
				<a href="#minus-square-o">
					<i class="fa fa-minus-square-o"></i>minus-square-o
				</a>
				<a href="#plus-square">
					<i class="fa fa-plus-square"></i>plus-square
				</a>
				<a href="#plus-square-o">
					<i class="fa fa-plus-square-o"></i>plus-square-o
				</a>
				<a href="#square">
					<i class="fa fa-square"></i>square
				</a>
				<a href="#square-o">
					<i class="fa fa-square-o"></i>square-o
				</a>
				<a href="#cc-amex">
					<i class="fa fa-cc-amex"></i>cc-amex
				</a>
				<a href="#cc-diners-club">
					<i class="fa fa-cc-diners-club"></i>cc-diners-club
				</a>
				<a href="#cc-discover">
					<i class="fa fa-cc-discover"></i>cc-discover
				</a>
				<a href="#cc-jcb">
					<i class="fa fa-cc-jcb"></i>cc-jcb
				</a>
				<a href="#cc-mastercard">
					<i class="fa fa-cc-mastercard"></i>cc-mastercard
				</a>
				<a href="#cc-paypal">
					<i class="fa fa-cc-paypal"></i>cc-paypal
				</a>
				<a href="#cc-stripe">
					<i class="fa fa-cc-stripe"></i>cc-stripe
				</a>
				<a href="#cc-visa">
					<i class="fa fa-cc-visa"></i>cc-visa
				</a>
				<a href="#credit-card">
					<i class="fa fa-credit-card"></i>credit-card
				</a>
				<a href="#credit-card-alt">
					<i class="fa fa-credit-card-alt"></i>credit-card-alt
				</a>
				<a href="#google-wallet">
					<i class="fa fa-google-wallet"></i>google-wallet
				</a>
				<a href="#paypal">
					<i class="fa fa-paypal"></i>paypal
				</a>
				<a href="#area-chart">
					<i class="fa fa-area-chart"></i>area-chart
				</a>
				<a href="#bar-chart">
					<i class="fa fa-bar-chart"></i>bar-chart
				</a>
				<a href="#bar-chart">
					<i class="fa fa-bar-chart-o"></i>bar-chart-o
				</a>
				<a href="#line-chart">
					<i class="fa fa-line-chart"></i>line-chart
				</a>
				<a href="#pie-chart">
					<i class="fa fa-pie-chart"></i>pie-chart
				</a>
				<a href="#btc">
					<i class="fa fa-bitcoin"></i>bitcoin
				</a>
				<a href="#btc">
					<i class="fa fa-btc"></i>btc
				</a>
				<a href="#jpy">
					<i class="fa fa-cny"></i>cny
				</a>
				<a href="#usd">
					<i class="fa fa-dollar"></i>dollar
				</a>
				<a href="#eur">
					<i class="fa fa-eur"></i>eur
				</a>
				<a href="#eur">
					<i class="fa fa-euro"></i>euro
				</a>
				<a href="#gbp">
					<i class="fa fa-gbp"></i>gbp
				</a>
				<a href="#gg">
					<i class="fa fa-gg"></i>gg
				</a>
				<a href="#gg-circle">
					<i class="fa fa-gg-circle"></i>gg-circle
				</a>
				<a href="#ils">
					<i class="fa fa-ils"></i>ils
				</a>
				<a href="#inr">
					<i class="fa fa-inr"></i>inr
				</a>
				<a href="#jpy">
					<i class="fa fa-jpy"></i>jpy
				</a>
				<a href="#krw">
					<i class="fa fa-krw"></i>krw
				</a>
				<a href="#money">
					<i class="fa fa-money"></i>money
				</a>
				<a href="#jpy">
					<i class="fa fa-rmb"></i>rmb
				</a>
				<a href="#rub">
					<i class="fa fa-rouble"></i>rouble
				</a>
				<a href="#rub">
					<i class="fa fa-rub"></i>rub
				</a>
				<a href="#rub">
					<i class="fa fa-ruble"></i>ruble
				</a>
				<a href="#inr">
					<i class="fa fa-rupee"></i>rupee
				</a>
				<a href="#ils">
					<i class="fa fa-shekel"></i>shekel
				</a>
				<a href="#ils">
					<i class="fa fa-sheqel"></i>sheqel
				</a>
				<a href="#try">
					<i class="fa fa-try"></i>try
				</a>
				<a href="#try">
					<i class="fa fa-turkish-lira"></i>turkish-lira
				</a>
				<a href="#usd">
					<i class="fa fa-usd"></i>usd
				</a>
				<a href="#krw">
					<i class="fa fa-won"></i>won
				</a>
				<a href="#jpy">
					<i class="fa fa-yen"></i>yen
				</a>
				<a href="#align-center">
					<i class="fa fa-align-center"></i>align-center
				</a>
				<a href="#align-justify">
					<i class="fa fa-align-justify"></i>align-justify
				</a>
				<a href="#align-left">
					<i class="fa fa-align-left"></i>align-left
				</a>
				<a href="#align-right">
					<i class="fa fa-align-right"></i>align-right
				</a>
				<a href="#bold">
					<i class="fa fa-bold"></i>bold
				</a>
				<a href="#link">
					<i class="fa fa-chain"></i>chain
				</a>
				<a href="#chain-broken">
					<i class="fa fa-chain-broken"></i>chain-broken
				</a>
				<a href="#clipboard">
					<i class="fa fa-clipboard"></i>clipboard
				</a>
				<a href="#columns">
					<i class="fa fa-columns"></i>columns
				</a>
				<a href="#files-o">
					<i class="fa fa-copy"></i>copy
				</a>
				<a href="#scissors">
					<i class="fa fa-cut"></i>cut
				</a>
				<a href="#outdent">
					<i class="fa fa-dedent"></i>dedent
				</a>
				<a href="#eraser">
					<i class="fa fa-eraser"></i>eraser
				</a>
				<a href="#file">
					<i class="fa fa-file"></i>file
				</a>
				<a href="#file-o">
					<i class="fa fa-file-o"></i>file-o
				</a>
				<a href="#file-text">
					<i class="fa fa-file-text"></i>file-text
				</a>
				<a href="#file-text-o">
					<i class="fa fa-file-text-o"></i>file-text-o
				</a>
				<a href="#files-o">
					<i class="fa fa-files-o"></i>files-o
				</a>
				<a href="#floppy-o">
					<i class="fa fa-floppy-o"></i>floppy-o
				</a>
				<a href="#font">
					<i class="fa fa-font"></i>font
				</a>
				<a href="#header">
					<i class="fa fa-header"></i>header
				</a>
				<a href="#indent">
					<i class="fa fa-indent"></i>indent
				</a>
				<a href="#italic">
					<i class="fa fa-italic"></i>italic
				</a>
				<a href="#link">
					<i class="fa fa-link"></i>link
				</a>
				<a href="#list">
					<i class="fa fa-list"></i>list
				</a>
				<a href="#list-alt">
					<i class="fa fa-list-alt"></i>list-alt
				</a>
				<a href="#list-ol">
					<i class="fa fa-list-ol"></i>list-ol
				</a>
				<a href="#list-ul">
					<i class="fa fa-list-ul"></i>list-ul
				</a>
				<a href="#outdent">
					<i class="fa fa-outdent"></i>outdent
				</a>
				<a href="#paperclip">
					<i class="fa fa-paperclip"></i>paperclip
				</a>
				<a href="#paragraph">
					<i class="fa fa-paragraph"></i>paragraph
				</a>
				<a href="#clipboard">
					<i class="fa fa-paste"></i>paste
				</a>
				<a href="#repeat">
					<i class="fa fa-repeat"></i>repeat
				</a>
				<a href="#undo">
					<i class="fa fa-rotate-left"></i>rotate-left
				</a>
				<a href="#repeat">
					<i class="fa fa-rotate-right"></i>rotate-right
				</a>
				<a href="#floppy-o">
					<i class="fa fa-save"></i>save
				</a>
				<a href="#scissors">
					<i class="fa fa-scissors"></i>scissors
				</a>
				<a href="#strikethrough">
					<i class="fa fa-strikethrough"></i>strikethrough
				</a>
				<a href="#subscript">
					<i class="fa fa-subscript"></i>subscript
				</a>
				<a href="#superscript">
					<i class="fa fa-superscript"></i>superscript
				</a>
				<a href="#table">
					<i class="fa fa-table"></i>table
				</a>
				<a href="#text-height">
					<i class="fa fa-text-height"></i>text-height
				</a>
				<a href="#text-width">
					<i class="fa fa-text-width"></i>text-width
				</a>
				<a href="#th">
					<i class="fa fa-th"></i>th
				</a>
				<a href="#th-large">
					<i class="fa fa-th-large"></i>th-large
				</a>
				<a href="#th-list">
					<i class="fa fa-th-list"></i>th-list
				</a>
				<a href="#underline">
					<i class="fa fa-underline"></i>underline
				</a>
				<a href="#undo">
					<i class="fa fa-undo"></i>undo
				</a>
				<a href="#chain-broken">
					<i class="fa fa-unlink"></i>unlink
				</a>
				<a href="#angle-double-down">
					<i class="fa fa-angle-double-down"></i>angle-double-down
				</a>
				<a href="#angle-double-left">
					<i class="fa fa-angle-double-left"></i>angle-double-left
				</a>
				<a href="#angle-double-right">
					<i class="fa fa-angle-double-right"></i>angle-double-right
				</a>
				<a href="#angle-double-up">
					<i class="fa fa-angle-double-up"></i>angle-double-up
				</a>
				<a href="#angle-down">
					<i class="fa fa-angle-down"></i>angle-down
				</a>
				<a href="#angle-left">
					<i class="fa fa-angle-left"></i>angle-left
				</a>
				<a href="#angle-right">
					<i class="fa fa-angle-right"></i>angle-right
				</a>
				<a href="#angle-up">
					<i class="fa fa-angle-up"></i>angle-up
				</a>
				<a href="#arrow-circle-down">
					<i class="fa fa-arrow-circle-down"></i>arrow-circle-down
				</a>
				<a href="#arrow-circle-left">
					<i class="fa fa-arrow-circle-left"></i>arrow-circle-left
				</a>
				<a href="#arrow-circle-o-down">
					<i class="fa fa-arrow-circle-o-down"></i>arrow-circle-o-down
				</a>
				<a href="#arrow-circle-o-left">
					<i class="fa fa-arrow-circle-o-left"></i>arrow-circle-o-left
				</a>
				<a href="#arrow-circle-o-right">
					<i class="fa fa-arrow-circle-o-right"></i>arrow-circle-o-right
				</a>
				<a href="#arrow-circle-o-up">
					<i class="fa fa-arrow-circle-o-up"></i>arrow-circle-o-up
				</a>
				<a href="#arrow-circle-right">
					<i class="fa fa-arrow-circle-right"></i>arrow-circle-right
				</a>
				<a href="#arrow-circle-up">
					<i class="fa fa-arrow-circle-up"></i>arrow-circle-up
				</a>
				<a href="#arrow-down">
					<i class="fa fa-arrow-down"></i>arrow-down
				</a>
				<a href="#arrow-left">
					<i class="fa fa-arrow-left"></i>arrow-left
				</a>
				<a href="#arrow-right">
					<i class="fa fa-arrow-right"></i>arrow-right
				</a>
				<a href="#arrow-up">
					<i class="fa fa-arrow-up"></i>arrow-up
				</a>
				<a href="#arrows">
					<i class="fa fa-arrows"></i>arrows
				</a>
				<a href="#arrows-alt">
					<i class="fa fa-arrows-alt"></i>arrows-alt
				</a>
				<a href="#arrows-h">
					<i class="fa fa-arrows-h"></i>arrows-h
				</a>
				<a href="#arrows-v">
					<i class="fa fa-arrows-v"></i>arrows-v
				</a>
				<a href="#caret-down">
					<i class="fa fa-caret-down"></i>caret-down
				</a>
				<a href="#caret-left">
					<i class="fa fa-caret-left"></i>caret-left
				</a>
				<a href="#caret-right">
					<i class="fa fa-caret-right"></i>caret-right
				</a>
				<a href="#caret-square-o-down">
					<i class="fa fa-caret-square-o-down"></i>caret-square-o-down
				</a>
				<a href="#caret-square-o-left">
					<i class="fa fa-caret-square-o-left"></i>caret-square-o-left
				</a>
				<a href="#caret-square-o-right">
					<i class="fa fa-caret-square-o-right"></i>caret-square-o-right
				</a>
				<a href="#caret-square-o-up">
					<i class="fa fa-caret-square-o-up"></i>caret-square-o-up
				</a>
				<a href="#caret-up">
					<i class="fa fa-caret-up"></i>caret-up
				</a>
				<a href="#chevron-circle-down">
					<i class="fa fa-chevron-circle-down"></i>chevron-circle-down
				</a>
				<a href="#chevron-circle-left">
					<i class="fa fa-chevron-circle-left"></i>chevron-circle-left
				</a>
				<a href="#chevron-circle-right">
					<i class="fa fa-chevron-circle-right"></i>chevron-circle-right
				</a>
				<a href="#chevron-circle-up">
					<i class="fa fa-chevron-circle-up"></i>chevron-circle-up
				</a>
				<a href="#chevron-down">
					<i class="fa fa-chevron-down"></i>chevron-down
				</a>
				<a href="#chevron-left">
					<i class="fa fa-chevron-left"></i>chevron-left
				</a>
				<a href="#chevron-right">
					<i class="fa fa-chevron-right"></i>chevron-right
				</a>
				<a href="#chevron-up">
					<i class="fa fa-chevron-up"></i>chevron-up
				</a>
				<a href="#exchange">
					<i class="fa fa-exchange"></i>exchange
				</a>
				<a href="#hand-o-down">
					<i class="fa fa-hand-o-down"></i>hand-o-down
				</a>
				<a href="#hand-o-left">
					<i class="fa fa-hand-o-left"></i>hand-o-left
				</a>
				<a href="#hand-o-right">
					<i class="fa fa-hand-o-right"></i>hand-o-right
				</a>
				<a href="#hand-o-up">
					<i class="fa fa-hand-o-up"></i>hand-o-up
				</a>
				<a href="#long-arrow-down">
					<i class="fa fa-long-arrow-down"></i>long-arrow-down
				</a>
				<a href="#long-arrow-left">
					<i class="fa fa-long-arrow-left"></i>long-arrow-left
				</a>
				<a href="#long-arrow-right">
					<i class="fa fa-long-arrow-right"></i>long-arrow-right
				</a>
				<a href="#long-arrow-up">
					<i class="fa fa-long-arrow-up"></i>long-arrow-up
				</a>
				<a href="#caret-square-o-down">
					<i class="fa fa-toggle-down"></i>toggle-down
				</a>
				<a href="#caret-square-o-left">
					<i class="fa fa-toggle-left"></i>toggle-left
				</a>
				<a href="#caret-square-o-right">
					<i class="fa fa-toggle-right"></i>toggle-right		
				</a>
				<a href="#caret-square-o-up">
					<i class="fa fa-toggle-up"></i>toggle-up		
				</a>
				<a href="#arrows-alt">
					<i class="fa fa-arrows-alt"></i>arrows-alt
				</a>
				<a href="#backward">
					<i class="fa fa-backward"></i>backward
				</a>
				<a href="#compress">
					<i class="fa fa-compress"></i>compress
				</a>
				<a href="#eject">
					<i class="fa fa-eject"></i>eject
				</a>
				<a href="#expand">
					<i class="fa fa-expand"></i>expand
				</a>
				<a href="#fast-backward">
					<i class="fa fa-fast-backward"></i>fast-backward
				</a>
				<a href="#fast-forward">
					<i class="fa fa-fast-forward"></i>fast-forward
				</a>
				<a href="#forward">
					<i class="fa fa-forward"></i>forward
				</a>
				<a href="#pause">
					<i class="fa fa-pause"></i>pause
				</a>
				<a href="#pause-circle">
					<i class="fa fa-pause-circle"></i>pause-circle
				</a>
				<a href="#pause-circle-o">
					<i class="fa fa-pause-circle-o"></i>pause-circle-o
				</a>
				<a href="#play">
					<i class="fa fa-play"></i>play
				</a>
				<a href="#play-circle">
					<i class="fa fa-play-circle"></i>play-circle
				</a>
				<a href="#play-circle-o">
					<i class="fa fa-play-circle-o"></i>play-circle-o
				</a>
				<a href="#random">
					<i class="fa fa-random"></i>random
				</a>
				<a href="#step-backward">
					<i class="fa fa-step-backward"></i>step-backward
				</a>
				<a href="#step-forward">
					<i class="fa fa-step-forward"></i>step-forward
				</a>
				<a href="#stop">
					<i class="fa fa-stop"></i>stop
				</a>
				<a href="#stop-circle">
					<i class="fa fa-stop-circle"></i>stop-circle
				</a>
				<a href="#stop-circle-o">
					<i class="fa fa-stop-circle-o"></i>stop-circle-o
				</a>
				<a href="#youtube-play">
					<i class="fa fa-youtube-play"></i>youtube-play
				</a>
				<a href="#500px">
					<i class="fa fa-500px"></i>500px
				</a>
				<a href="#adn">
					<i class="fa fa-adn"></i>adn
				</a>
				<a href="#amazon">
					<i class="fa fa-amazon"></i>amazon
				</a>
				<a href="#android">
					<i class="fa fa-android"></i>android
				</a>
				<a href="#angellist">
					<i class="fa fa-angellist"></i>angellist
				</a>
				<a href="#apple">
					<i class="fa fa-apple"></i>apple
				</a>
				<a href="#bandcamp">
					<i class="fa fa-bandcamp"></i>bandcamp
				</a>
				<a href="#behance">
					<i class="fa fa-behance"></i>behance
				</a>
				<a href="#behance-square">
					<i class="fa fa-behance-square"></i>behance-square
				</a>
				<a href="#bitbucket">
					<i class="fa fa-bitbucket"></i>bitbucket
				</a>
				<a href="#bitbucket-square">
					<i class="fa fa-bitbucket-square"></i>bitbucket-square
				</a>
				<a href="#btc">
					<i class="fa fa-bitcoin"></i>bitcoin
				</a>
				<a href="#black-tie">
					<i class="fa fa-black-tie"></i>black-tie
				</a>
				<a href="#bluetooth">
					<i class="fa fa-bluetooth"></i>bluetooth
				</a>
				<a href="#bluetooth-b">
					<i class="fa fa-bluetooth-b"></i>bluetooth-b
				</a>
				<a href="#btc">
					<i class="fa fa-btc"></i>btc
				</a>
				<a href="#buysellads">
					<i class="fa fa-buysellads"></i>buysellads
				</a>
				<a href="#cc-amex">
					<i class="fa fa-cc-amex"></i>cc-amex
				</a>
				<a href="#cc-diners-club">
					<i class="fa fa-cc-diners-club"></i>cc-diners-club
				</a>
				<a href="#cc-discover">
					<i class="fa fa-cc-discover"></i>cc-discover
				</a>
				<a href="#cc-jcb">
					<i class="fa fa-cc-jcb"></i>cc-jcb
				</a>
				<a href="#cc-mastercard">
					<i class="fa fa-cc-mastercard"></i>cc-mastercard
				</a>
				<a href="#cc-paypal">
					<i class="fa fa-cc-paypal"></i>cc-paypal
				</a>
				<a href="#cc-stripe">
					<i class="fa fa-cc-stripe"></i>cc-stripe
				</a>
				<a href="#cc-visa">
					<i class="fa fa-cc-visa"></i>cc-visa
				</a>
				<a href="#chrome">
					<i class="fa fa-chrome"></i>chrome
				</a>
				<a href="#codepen">
					<i class="fa fa-codepen"></i>codepen
				</a>
				<a href="#codiepie">
					<i class="fa fa-codiepie"></i>codiepie
				</a>
				<a href="#connectdevelop">
					<i class="fa fa-connectdevelop"></i>connectdevelop
				</a>
				<a href="#contao">
					<i class="fa fa-contao"></i>contao
				</a>
				<a href="#css3">
					<i class="fa fa-css3"></i>css3
				</a>
				<a href="#dashcube">
					<i class="fa fa-dashcube"></i>dashcube
				</a>
				<a href="#delicious">
					<i class="fa fa-delicious"></i>delicious
				</a>
				<a href="#deviantart">
					<i class="fa fa-deviantart"></i>deviantart
				</a>
				<a href="#digg">
					<i class="fa fa-digg"></i>digg
				</a>
				<a href="#dribbble">
					<i class="fa fa-dribbble"></i>dribbble
				</a>
				<a href="#dropbox">
					<i class="fa fa-dropbox"></i>dropbox
				</a>
				<a href="#drupal">
					<i class="fa fa-drupal"></i>drupal
				</a>
				<a href="#edge">
					<i class="fa fa-edge"></i>edge
				</a>
				<a href="#eercast">
					<i class="fa fa-eercast"></i>eercast
				</a>
				<a href="#empire">
					<i class="fa fa-empire"></i>empire
				</a>
				<a href="#envira">
					<i class="fa fa-envira"></i>envira
				</a>
				<a href="#etsy">
					<i class="fa fa-etsy"></i>etsy
				</a>
				<a href="#expeditedssl">
					<i class="fa fa-expeditedssl"></i>expeditedssl
				</a>
				<a href="#font-awesome">
					<i class="fa fa-fa"></i>fa
				</a>
				<a href="#facebook">
					<i class="fa fa-facebook"></i>facebook
				</a>
				<a href="#facebook">
					<i class="fa fa-facebook-f"></i>facebook-f
				</a>
				<a href="#facebook-official">
					<i class="fa fa-facebook-official"></i>facebook-official
				</a>
				<a href="#facebook-square">
					<i class="fa fa-facebook-square"></i>facebook-square
				</a>
				<a href="#firefox">
					<i class="fa fa-firefox"></i>firefox
				</a>
				<a href="#first-order">
					<i class="fa fa-first-order"></i>first-order
				</a>
				<a href="#flickr">
					<i class="fa fa-flickr"></i>flickr
				</a>
				<a href="#font-awesome">
					<i class="fa fa-font-awesome"></i>font-awesome
				</a>
				<a href="#fonticons">
					<i class="fa fa-fonticons"></i>fonticons
				</a>
				<a href="#fort-awesome">
					<i class="fa fa-fort-awesome"></i>fort-awesome
				</a>
				<a href="#forumbee">
					<i class="fa fa-forumbee"></i>forumbee
				</a>
				<a href="#foursquare">
					<i class="fa fa-foursquare"></i>foursquare
				</a>
				<a href="#free-code-camp">
					<i class="fa fa-free-code-camp"></i>free-code-camp
				</a>
				<a href="#empire">
					<i class="fa fa-ge"></i>ge
				</a>
				<a href="#get-pocket">
					<i class="fa fa-get-pocket"></i>get-pocket
				</a>
				<a href="#gg">
					<i class="fa fa-gg"></i>gg
				</a>
				<a href="#gg-circle">
					<i class="fa fa-gg-circle"></i>gg-circle
				</a>
				<a href="#git">
					<i class="fa fa-git"></i>git
				</a>
				<a href="#git-square">
					<i class="fa fa-git-square"></i>git-square
				</a>
				<a href="#github">
					<i class="fa fa-github"></i>github
				</a>
				<a href="#github-alt">
					<i class="fa fa-github-alt"></i>github-alt
				</a>
				<a href="#github-square">
					<i class="fa fa-github-square"></i>github-square
				</a>
				<a href="#gitlab">
					<i class="fa fa-gitlab"></i>gitlab
				</a>
				<a href="#gratipay">
					<i class="fa fa-gittip"></i>gittip
				</a>
				<a href="#glide">
					<i class="fa fa-glide"></i>glide
				</a>
				<a href="#glide-g">
					<i class="fa fa-glide-g"></i>glide-g
				</a>
				<a href="#google">
					<i class="fa fa-google"></i>google
				</a>
				<a href="#google-plus">
					<i class="fa fa-google-plus"></i>google-plus
				</a>
				<a href="#google-plus-official">
					<i class="fa fa-google-plus-circle"></i>google-plus-circle
				</a>
				<a href="#google-plus-official">
					<i class="fa fa-google-plus-official"></i>google-plus-official
				</a>
				<a href="#google-plus-square">
					<i class="fa fa-google-plus-square"></i>google-plus-square
				</a>
				<a href="#google-wallet">
					<i class="fa fa-google-wallet"></i>google-wallet
				</a>
				<a href="#gratipay">
					<i class="fa fa-gratipay"></i>gratipay
				</a>
				<a href="#grav">
					<i class="fa fa-grav"></i>grav
				</a>
				<a href="#hacker-news">
					<i class="fa fa-hacker-news"></i>hacker-news
				</a>
				<a href="#houzz">
					<i class="fa fa-houzz"></i>houzz
				</a>
				<a href="#html5">
					<i class="fa fa-html5"></i>html5
				</a>
				<a href="#imdb">
					<i class="fa fa-imdb"></i>imdb
				</a>
				<a href="#instagram">
					<i class="fa fa-instagram"></i>instagram
				</a>
				<a href="#internet-explorer">
					<i class="fa fa-internet-explorer"></i>internet-explorer
				</a>
				<a href="#ioxhost">
					<i class="fa fa-ioxhost"></i>ioxhost
				</a>
				<a href="#joomla">
					<i class="fa fa-joomla"></i>joomla
				</a>
				<a href="#jsfiddle">
					<i class="fa fa-jsfiddle"></i>jsfiddle
				</a>
				<a href="#lastfm">
					<i class="fa fa-lastfm"></i>lastfm
				</a>
				<a href="#lastfm-square">
					<i class="fa fa-lastfm-square"></i>lastfm-square
				</a>
				<a href="#leanpub">
					<i class="fa fa-leanpub"></i>leanpub
				</a>
				<a href="#linkedin">
					<i class="fa fa-linkedin"></i>linkedin
				</a>
				<a href="#linkedin-square">
					<i class="fa fa-linkedin-square"></i>linkedin-square
				</a>
				<a href="#linode">
					<i class="fa fa-linode"></i>linode
				</a>
				<a href="#linux">
					<i class="fa fa-linux"></i>linux
				</a>
				<a href="#maxcdn">
					<i class="fa fa-maxcdn"></i>maxcdn
				</a>
				<a href="#meanpath">
					<i class="fa fa-meanpath"></i>meanpath
				</a>
				<a href="#medium">
					<i class="fa fa-medium"></i>medium
				</a>
				<a href="#meetup">
					<i class="fa fa-meetup"></i>meetup
				</a>
				<a href="#mixcloud">
					<i class="fa fa-mixcloud"></i>mixcloud
				</a>
				<a href="#modx">
					<i class="fa fa-modx"></i>modx
				</a>
				<a href="#odnoklassniki">
					<i class="fa fa-odnoklassniki"></i>odnoklassniki
				</a>
				<a href="#odnoklassniki-square">
					<i class="fa fa-odnoklassniki-square"></i>odnoklassniki-square
				</a>
				<a href="#opencart">
					<i class="fa fa-opencart"></i>opencart
				</a>
				<a href="#openid">
					<i class="fa fa-openid"></i>openid
				</a>
				<a href="#opera">
					<i class="fa fa-opera"></i>opera
				</a>
				<a href="#optin-monster">
					<i class="fa fa-optin-monster"></i>optin-monster
				</a>
				<a href="#pagelines">
					<i class="fa fa-pagelines"></i>pagelines
				</a>
				<a href="#paypal">
					<i class="fa fa-paypal"></i>paypal
				</a>
				<a href="#pied-piper">
					<i class="fa fa-pied-piper"></i>pied-piper
				</a>
				<a href="#pied-piper-alt">
					<i class="fa fa-pied-piper-alt"></i>pied-piper-alt
				</a>
				<a href="#pied-piper-pp">
					<i class="fa fa-pied-piper-pp"></i>pied-piper-pp
				</a>
				<a href="#pinterest">
					<i class="fa fa-pinterest"></i>pinterest
				</a>
				<a href="#pinterest-p">
					<i class="fa fa-pinterest-p"></i>pinterest-p
				</a>
				<a href="#pinterest-square">
					<i class="fa fa-pinterest-square"></i>pinterest-square
				</a>
				<a href="#product-hunt">
					<i class="fa fa-product-hunt"></i>product-hunt
				</a>
				<a href="#qq">
					<i class="fa fa-qq"></i>qq
				</a>
				<a href="#quora">
					<i class="fa fa-quora"></i>quora
				</a>
				<a href="#rebel">
					<i class="fa fa-ra"></i>ra
				</a>
				<a href="#ravelry">
					<i class="fa fa-ravelry"></i>ravelry
				</a>
				<a href="#rebel">
					<i class="fa fa-rebel"></i>rebel
				</a>
				<a href="#reddit">
					<i class="fa fa-reddit"></i>reddit
				</a>
				<a href="#reddit-alien">
					<i class="fa fa-reddit-alien"></i>reddit-alien
				</a>
				<a href="#reddit-square">
					<i class="fa fa-reddit-square"></i>reddit-square
				</a>
				<a href="#renren">
					<i class="fa fa-renren"></i>renren
				</a>
				<a href="#rebel">
					<i class="fa fa-resistance"></i>resistance
				</a>
				<a href="#safari">
					<i class="fa fa-safari"></i>safari
				</a>
				<a href="#scribd">
					<i class="fa fa-scribd"></i>scribd
				</a>
				<a href="#sellsy">
					<i class="fa fa-sellsy"></i>sellsy
				</a>
				<a href="#share-alt">
					<i class="fa fa-share-alt"></i>share-alt
				</a>
				<a href="#share-alt-square">
					<i class="fa fa-share-alt-square"></i>share-alt-square
				</a>
				<a href="#shirtsinbulk">
					<i class="fa fa-shirtsinbulk"></i>shirtsinbulk
				</a>
				<a href="#simplybuilt">
					<i class="fa fa-simplybuilt"></i>simplybuilt
				</a>
				<a href="#skyatlas">
					<i class="fa fa-skyatlas"></i>skyatlas
				</a>
				<a href="#skype">
					<i class="fa fa-skype"></i>skype
				</a>
				<a href="#slack">
					<i class="fa fa-slack"></i>slack
				</a>
				<a href="#slideshare">
					<i class="fa fa-slideshare"></i>slideshare
				</a>
				<a href="#snapchat">
					<i class="fa fa-snapchat"></i>snapchat
				</a>
				<a href="#snapchat-ghost">
					<i class="fa fa-snapchat-ghost"></i>snapchat-ghost
				</a>
				<a href="#snapchat-square">
					<i class="fa fa-snapchat-square"></i>snapchat-square
				</a>
				<a href="#soundcloud">
					<i class="fa fa-soundcloud"></i>soundcloud
				</a>
				<a href="#spotify">
					<i class="fa fa-spotify"></i>spotify
				</a>
				<a href="#stack-exchange">
					<i class="fa fa-stack-exchange"></i>stack-exchange
				</a>
				<a href="#stack-overflow">
					<i class="fa fa-stack-overflow"></i>stack-overflow
				</a>
				<a href="#steam">
					<i class="fa fa-steam"></i>steam
				</a>
				<a href="#steam-square">
					<i class="fa fa-steam-square"></i>steam-square
				</a>
				<a href="#stumbleupon">
					<i class="fa fa-stumbleupon"></i>stumbleupon
				</a>
				<a href="#stumbleupon-circle">
					<i class="fa fa-stumbleupon-circle"></i>stumbleupon-circle
				</a>
				<a href="#superpowers">
					<i class="fa fa-superpowers"></i>superpowers
				</a>
				<a href="#telegram">
					<i class="fa fa-telegram"></i>telegram
				</a>
				<a href="#tencent-weibo">
					<i class="fa fa-tencent-weibo"></i>tencent-weibo
				</a>
				<a href="#themeisle">
					<i class="fa fa-themeisle"></i>themeisle
				</a>
				<a href="#trello">
					<i class="fa fa-trello"></i>trello
				</a>
				<a href="#tripadvisor">
					<i class="fa fa-tripadvisor"></i>tripadvisor
				</a>
				<a href="#tumblr">
					<i class="fa fa-tumblr"></i>tumblr
				</a>
				<a href="#tumblr-square">
					<i class="fa fa-tumblr-square"></i>tumblr-square
				</a>
				<a href="#twitch">
					<i class="fa fa-twitch"></i>twitch
				</a>
				<a href="#twitter">
					<i class="fa fa-twitter"></i>twitter
				</a>
				<a href="#twitter-square">
					<i class="fa fa-twitter-square"></i>twitter-square
				</a>
				<a href="#usb">
					<i class="fa fa-usb"></i>usb
				</a>
				<a href="#viacoin">
					<i class="fa fa-viacoin"></i>viacoin
				</a>
				<a href="#viadeo">
					<i class="fa fa-viadeo"></i>viadeo
				</a>
				<a href="#viadeo-square">
					<i class="fa fa-viadeo-square"></i>viadeo-square
				</a>
				<a href="#vimeo">
					<i class="fa fa-vimeo"></i>vimeo
				</a>
				<a href="#vimeo-square">
					<i class="fa fa-vimeo-square"></i>vimeo-square
				</a>
				<a href="#vine">
					<i class="fa fa-vine"></i>vine
				</a>
				<a href="#vk">
					<i class="fa fa-vk"></i>vk
				</a>
				<a href="#weixin">
					<i class="fa fa-wechat"></i>wechat
				</a>
				<a href="#weibo">
					<i class="fa fa-weibo"></i>weibo
				</a>
				<a href="#weixin">
					<i class="fa fa-weixin"></i>weixin
				</a>
				<a href="#whatsapp">
					<i class="fa fa-whatsapp"></i>whatsapp
				</a>
				<a href="#wikipedia-w">
					<i class="fa fa-wikipedia-w"></i>wikipedia-w
				</a>
				<a href="#windows">
					<i class="fa fa-windows"></i>windows
				</a>
				<a href="#wordpress">
					<i class="fa fa-wordpress"></i>wordpress
				</a>
				<a href="#wpbeginner">
					<i class="fa fa-wpbeginner"></i>wpbeginner
				</a>
				<a href="#wpexplorer">
					<i class="fa fa-wpexplorer"></i>wpexplorer
				</a>
				<a href="#wpforms">
					<i class="fa fa-wpforms"></i>wpforms
				</a>
				<a href="#xing">
					<i class="fa fa-xing"></i>xing
				</a>
				<a href="#xing-square">
					<i class="fa fa-xing-square"></i>xing-square
				</a>
				<a href="#y-combinator">
					<i class="fa fa-y-combinator"></i>y-combinator
				</a>
				<a href="#hacker-news">
					<i class="fa fa-y-combinator-square"></i>y-combinator-square
				</a>
				<a href="#yahoo">
					<i class="fa fa-yahoo"></i>yahoo
				</a>
				<a href="#y-combinator">
					<i class="fa fa-yc"></i>yc
				</a>
				<a href="#hacker-news">
					<i class="fa fa-yc-square"></i>yc-square
				</a>
				<a href="#yelp">
					<i class="fa fa-yelp"></i>yelp
				</a>
				<a href="#yoast">
					<i class="fa fa-yoast"></i>yoast
				</a>
				<a href="#youtube">
					<i class="fa fa-youtube"></i>youtube
				</a>
				<a href="#youtube-play">
					<i class="fa fa-youtube-play"></i>youtube-play
				</a>
				<a href="#youtube-square">
					<i class="fa fa-youtube-square"></i>youtube-square
				</a>
				<div class="clear"></div>
			</div>

			<div class="footer">
				<div class="decoration decoration-margins"></div>
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="decoration decoration-margins"></div>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					<a href="https://plus.google.com/u/2/105775801838187143320" class="google-bg"><i class="fa fa-google-plus"></i></a>
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>

			
		</div>
	</div>

	
</body>
</html>