<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-instagram" src="https://cdn.ampproject.org/v0/amp-instagram-0.1.js"></script>
<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom>body{font-family:'Roboto', sans-serif; font-size:14px; background-color:#FFFFFF;}

/*Color Schemes and Colors*/

.footer-logo{}
header{background-color:#1f1f1f; border-bottom:solid 1px rgba(0,0,0,0.1);}
nav{
    background: rgb(46,46,46);
    background: -moz-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(46,46,46,1)),color-stop(49%,rgba(31,31,31,1)),color-stop(50%,rgba(0,0,0,1)),color-stop(100%,rgba(0,0,0,1)));
    background: -webkit-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: -o-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: -ms-linear-gradient(top,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    background: linear-gradient(to bottom,rgba(46,46,46,1) 0%,rgba(31,31,31,1) 49%,rgba(0,0,0,1) 50%,rgba(0,0,0,1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#2e2e2e',endColorstr='#000000',GradientType=0);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#bcbcbc', endColorstr='#0a0809',GradientType=0 ); /* IE6-9 */filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#45484d', endColorstr='#000000',GradientType=0 ); /* IE6-9 */
}
nav a{color:#FFFFFF;}
.header-icon-1, .header-icon-2{color:#FFFFFF;}
.menu-item em{color:#000000; font-weight:500; font-size:12px; font-style: normal;}
.menu-item strong{color:#fd4c29; font-weight:500; font-size:14px;}
.header-clear{height:30px; display:block;}

.bg-teal-light{ background-color: #1abc9c; color:#FFFFFF}
.bg-teal-dark{  background-color: #16a085; color:#FFFFFF}
.border-teal-light{ border:solid 1px #1abc9c;}
.border-teal-dark{  border:solid 1px #16a085;}
.color-teal-light{ color: #1abc9c;}
.color-teal-dark{  color: #16a085;}
.bg-green-light{background-color: #2ecc71; color:#FFFFFF}
.bg-green-dark{background-color: #2abb67; color:#FFFFFF}
.border-green-light{border:solid 1px #2ecc71;}
.border-green-dark{ border:solid 1px #2abb67;}
.color-green-light{color: #2ecc71;}
.color-green-dark{color: #2abb67;}
.bg-blue-light{background-color: #3498db; color:#FFFFFF}
.bg-blue-dark{background-color: #2980b9; color:#FFFFFF;}
.border-blue-light{border:solid 1px #3498db;}
.border-blue-dark{ border:solid 1px #2980b9;}
.color-blue-light{color: #3498db;}
.color-blue-dark{color: #2980b9;}
.bg-magenta-light{background-color: #9b59b6; color:#FFFFFF}
.bg-magenta-dark{background-color: #8e44ad; color:#FFFFFF}
.border-magenta-light{border:solid 1px #9b59b6;}
.border-magenta-dark{ border:solid 1px #8e44ad;}
.color-magenta-light{color: #9b59b6;}
.color-magenta-dark{color: #8e44ad;}
.bg-night-light{background-color: #34495e; color:#FFFFFF}
.bg-night-dark{background-color: #2c3e50; color:#FFFFFF}
.border-night-light{border:solid 1px #34495e;}
.border-night-dark{ border:solid 1px #2c3e50;}
.color-night-light{color: #34495e;}
.color-night-dark{color: #2c3e50;}
.bg-yellow-light{background-color: #E67E22; color:#FFFFFF}
.bg-yellow-dark{background-color: #e86f2a; color:#FFFFFF}
.border-yellow-light{border:solid 1px #E67E22;}
.border-yellow-dark{ border:solid 1px #F27935;}
.color-yellow-light{color: #f1c40f;}
.color-yellow-dark{color: #f39c12;}
.bg-orange-light{background-color: #F9690E; color:#FFFFFF}
.bg-orange-dark{background-color: #D35400; color:#FFFFFF}
.border-orange-light{border:solid 1px #F9690E;}
.border-orange-dark{ border:solid 1px #D35400;}
.color-orange-light{color: #e67e22;}
.color-orange-dark{color: #d35400;}
.bg-red-light{background-color: #e74c3c; color:#FFFFFF}
.bg-red-dark{background-color: #c0392b; color:#FFFFFF}
.border-red-light{border:solid 1px #e74c3c;}
.border-red-dark{ border:solid 1px #c0392b;}
.color-red-light{color: #e74c3c;}
.color-red-dark{color: #c0392b;}
.bg-pink-light{background-color: #fa6a8e ; color:#FFFFFF}
.bg-pink-dark{background-color: #FB3365 ; color:#FFFFFF}
.border-pink-light{border:solid 1px #fa6a8e ;}
.border-pink-dark{ border:solid 1px #FB3365 ;}
.color-pink-light{color: #fa6a8e;}
.color-pink-dark{color: #FB3365;}
.bg-gray-light{background-color: #bdc3c7; color:#FFFFFF}
.bg-gray-dark{background-color: #95a5a6; color:#FFFFFF}
.border-gray-light{border:solid 1px #bdc3c7;}
.border-gray-dark{ border:solid 1px #95a5a6;}
.color-gray-light{color: #bdc3c7;}
.color-gray-dark{color: #95a5a6;}
.bg-white{background-color:#FFFFFF;}
.color-white{color:#FFFFFF;}
.border-white{border:solid 1px #FFFFFF;}
.bg-black{background-color:#000000;}
.color-black{color:#000000;}
.border-black{border:solid 1px #000000;}
.color-heading{color:#676767;}

/*Social Icons*/
.facebook-bg{background-color:#3b5998; color:#FFFFFF;}
.linkedin-bg{background-color:#0077B5; color:#FFFFFF;}
.twitter-bg{background-color:#4099ff; color:#FFFFFF;}
.google-bg{ background-color:#d34836; color:#FFFFFF;}
.whatsapp-bg{ background-color:#34AF23; color:#FFFFFF;}
.pinterest-bg{ background-color:#C92228; color:#FFFFFF;}
.sms-bg{ background-color:#27ae60; color:#FFFFFF;}
.mail-bg{ background-color:#3498db; color:#FFFFFF;}
.dribbble-bg{ background-color:#EA4C89; color:#FFFFFF;}
.tumblr-bg{ background-color:#2C3D52; color:#FFFFFF;}
.reddit-bg{ background-color:#336699; color:#FFFFFF;}
.youtube-bg{ background-color:#D12827; color:#FFFFFF;}
.phone-bg{ background-color:#27ae60; color:#FFFFFF;}
.skype-bg{ background-color:#12A5F4; color:#FFFFFF;}
.facebook-color{    color:#3b5998;}
.linkedin-color{    color:#0077B5;}
.twitter-color{     color:#4099ff;}
.google-color{      color:#d34836;}
.whatsapp-color{    color:#34AF23;}
.pinterest-color{   color:#C92228;}
.sms-color{         color:#27ae60;}
.mail-color{        color:#3498db;}
.dribbble-color{    color:#EA4C89;}
.tumblr-color{      color:#2C3D52;}
.reddit-color{      color:#336699;}
.youtube-color{     color:#D12827;}
.phone-color{       color:#27ae60;}
.skype-color{       color:#12A5F4;}

/*Background Images*/
.bg-1{background-image:url(images/pictures/1.jpg)}
.bg-2{background-image:url(images/pictures/2.jpg)}
.bg-3{background-image:url(images/pictures/3.jpg)}
.bg-4{background-image:url(images/pictures/4.jpg)}
.bg-5{background-image:url(images/pictures/5.jpg)}
.bg-6{background-image:url(images/pictures/6.jpg)}
.bg-7{background-image:url(images/pictures/7.jpg)}
.bg-8{background-image:url(images/pictures/8.jpg)}
.bg-9{background-image:url(images/pictures/9.jpg)}
.bg-body-1{background-image:url(images/pictures_vertical/bg1.jpg)}
.bg-body-2{background-image:url(images/pictures_vertical/bg0.jpg)}
.overlay{background-color:rgba(0,0,0,0.8); position:absolute; top:0px; right:0px; bottom:0px; left:0px;}

/*Font Settings*/
h1{ font-size:24px; line-height:34px; font-weight:500;}
h2{ font-size:22px; line-height:32px; font-weight:500;}
h3{ font-size:20px; line-height:30px; font-weight:500;}
h4{ font-size:18px; line-height:28px; font-weight:500;}
h5{ font-size:16px; line-height:26px; font-weight:500;}
h6{ font-size:14px; line-height:22px; font-weight:800;}
.ultrathin{font-weight:200;}
.thin{font-weight:300;}
.thiner{font-weight:400;}
.boder{font-weight:600;}
.bold{font-weight:700;}
.ultrabold{font-weight:800;}
.capitalize{text-transform: capitalize;}
.italic{font-style: italic;}
.small-text{font-size:12px; display:block;}
.center-text{text-align:center; display:block;}
.right-text{text-align:right;}
.uppercase{text-transform: uppercase;}
.boxed-text{width:74%; margin:0px auto 30px auto;}
.round-image{border-radius:500px;}
p a{display:inline;}

/*Content Settings*/
.content{padding:0px 20px 0px 20px}
.container{margin-bottom:30px}
.full-bottom{margin-bottom:25px}
.no-bottom{margin-bottom:0px}
.negative-bottom{margin-bottom:-10px;}
.full-top{margin-top:25px}
.half-bottom{margin-bottom:15px}
.half-top{margin-top:15px}
.quarter-bottom{margin-bottom:15px}
.hidden{display:none}
.left-column{width:45%; margin-right:5%; float:left}
.right-column{width:45%; margin-left:5%; float:left}
.one-third-left{float:left; width:29%;  margin-right:1%}
.one-third-center{float:left; width:29%; margin-left:5%; margin-right:5%}
.one-third-right{float:left; width:29%; margin-left:1%}
.clear{clear:both;}

* {
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	vertical-align: baseline;
	outline: none;
	font-size-adjust: none;
	-webkit-text-size-adjust: none;
	-moz-text-size-adjust: none;
	-ms-text-size-adjust: none;
	-webkit-tap-highlight-color: rgba(0,0,0,0);
    -webkit-font-smoothing: antialiased;
    -webkit-transform: translate3d(1,1,1);
    transform:translate3d(1,1,1);    
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

div, a, p, img, blockquote, form, fieldset, textarea, input, label, iframe, code, pre {
	display: block;
	position:relative;
}

p{
	line-height:30px; 
	font-weight:400; 
	color:#666666; 
	font-size:14px; 
	margin-bottom:30px;
}

a{text-decoration:none; color:#3498db;} 

/*Lists*/
.icon-list{list-style:none; font-size:14px; line-height:35px; color:#666666;}
.icon-list i{width:30px; font-size:15px;}

.center-icon{
	width:80px;
	height:80px;
	border-radius:80px;
	border:solid 1px rgba(0,0,0,0.5);
	text-align:center;
	line-height:80px;
	font-size:24px;
	margin:0px auto 30px auto;
	display:block;
}

.decoration, .decoration-no-bottom{
	height:1px; 
	background-color:rgba(0,0,0,0.1);
}

.deco{height:1px; margin-bottom:30px;}

.deco-box .deco{
	width:10%;
	float:left;
	height:5px;
}

.decoration{margin-bottom:30px;}
.decoration-margins{margin:0px 20px 30px 20px}

/*Image Effect*/

.image-border{
	padding:10px;
	border:solid 6px #FFFFFF;
	-webkit-box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
	box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
	border-radius:5px;
}

/*Page Content*/

::-webkit-scrollbar { width: 0; }

.menu *{
	user-select: none;
	-moz-user-select: none;
	-webkit-user-select: none;
}

/*Header*/
header{
	top:0px;
	height:55px;
	width:100%;
	z-index:9999;
	transition:all 250ms ease;
}

.footer-logo{
	background-image:url(images/logo_dark.png);
	margin:0 auto 10px auto;
	background-repeat: no-repeat;
	background-position:center center;
	background-size:130px 40px;
	width:130px;
	height:40px;
	display:block;
	overflow:hidden;
}

.header-icon-1, .header-icon-2{
	position:absolute;
	line-height:60px; 
	text-align:center; 
	width:60px;
	display:block;
	background-color:transparent;
}

.header-icon-2{
	right:0px; 
	top:0px;
}

.header-icon-1{
	left:0px;
	top:0px;
}

.header-logo{
	background-image:url(images/logo_light.png);
	margin:0 auto;
	background-repeat: no-repeat;
	background-position:center center;
	background-size:100px 29px;
	width:105px;
	height:60px;
	display:block;
	overflow:hidden;
}

/*Navigation*/

nav{
	z-index:9999999;
	height:60px;
	position:fixed;
	bottom:0px;
	left:0px;
	right:0px;
}

.copyright{margin-bottom:90px; margin-top:30px;}

.footer-7-icons a{width:14.285714%;}
.footer-6-icons a{width:16.6667%;}
.footer-5-icons a{width:20%;}
.footer-4-icons a{width:25%;}
.footer-3-icons a{width:33.333%;}

nav a{
	box-sizing: border-box;
	float:left;
	text-align:center;
	font-size:15px;
	height:60px;
	border-right:solid 1px rgba(255,255,255,0.05);
	border-left:solid 1px rgba(0,0,0,1);
}
nav a i{
	margin-top:13px;
	display:block;
	height:23px;
	line-height:23px;
}

nav a em{
	display:block;
	font-size:10px;
	opacity:0.8;
	text-transform:uppercase;
	font-style:normal;
}

.active-item{background-color:rgba(255,255,255,0.08);}

.footer{margin-bottom:80px;}

.icon-12{font-size:12px;}
.icon-13{font-size:13px;}
.icon-14{font-size:14px;}
.icon-15{font-size:15px;}
.icon-16{font-size:16px;}
.icon-17{font-size:17px;}
.icon-18{font-size:18px;}
.icon-19{font-size:19px;}
.icon-20{font-size:20px;}


.footer-socials a{
	width:40px;
	height:40px;
	line-height:40px;
	margin-left:2px;
	margin-right:2px;
	text-align:center;
	float:left;
	border-radius:5px;
}

.footer-socials{
	width:265px;
	margin:0px auto 30px auto;
}


/*Icons & Captions*/

.news-slider .caption{
	background-color:rgba(0,0,0,0.8);
}

.caption{
	position:absolute;
	bottom:0px;
	left:0px;
	right:0px;
	height:65px;
	padding-left:20px;
	padding-right:20px;
	background-color:rgba(0,0,0,0.8);
}

.caption h4{
	font-size:14px;
	color:#FFFFFF;
	line-height:20px;
	margin-top:12px;
}

.caption h3{
	color:#FFFFFF;
	margin-bottom:5px;
	font-size:17px;
	padding-top:23px;
	line-height:0px;
}

.caption p{
	font-size:12px;
	color:rgba(255,255,255,0.5);
}


.call-to-action{
	width:245px;
	margin:0 auto;
}

.call-to-action a{margin:0px 5px; font-size:11px;}


.social-icons{
	width:150px;
	margin:0 auto;
}

.social-round a{border-radius:50px;}

.social-icons-small{
	width:95px;
	margin:0 auto;
}

.social-icons a{
	line-height:35px;
	width:35px;
	height:35px;
	margin-left:10px;
	margin-right:5px;
	float:left;
	font-size:12px;
}

.social-icons-small a{
	line-height:35px;
	width:35px;
	height:35px;
	margin-left:5px;
	margin-right:5px;
	float:left;
}

/*Large Link*/
.large-link{
	font-size:13px;
	height:50px;
	line-height:50px;
	color:#000000;
	border-bottom:solid 1px rgba(0,0,0,0.1);
}

.large-link .fa-caret-right{
	font-size:10px;
	position:absolute;
	right:-25px;
	line-height:50px;
}

.large-link .fa-angle-right{
	position:absolute;
	right:0px;
	height:50px;
	line-height:50px;
	width:10px;
}

.large-link-deco{height:1px; margin-bottom:3px; background-color:rgba(0,0,0,0.1);}
.large-link i:last-child{width:20px; margin-right:20px; text-align:center;}


/*Heading Block*/
.heading-box{padding:20px 20px 20px 20px; margin-bottom:30px;}
.heading-box h3{margin-bottom:-5px; font-size:17px; position:relative; z-index:10;}
.heading-box p{position:relative; z-index:10; margin-bottom:0px; color:rgba(255,255,255,0.4);}
.heading-box i{padding:0px 5px 0px 5px;}

.heading-block{
	padding:30px 20px;
	margin-bottom:30px;
}

.heading-block h4{
	font-size:20px;
	position:relative;
	z-index:10;
	color:#FFFFFF;
}

.heading-block p{
	position:relative;
	z-index:10;
	color:rgba(255,255,255,0.5);
	margin-bottom:0px;
}

.heading-block a{
	z-index:10;
	width:100px;
	height:10px;
	line-height:10px;
	color:#FFFFFF;
	text-align:center;
	font-size:12px;
	margin:20px auto 0px auto;
	border:solid 1px rgba(255,255,255,0.5);
	border-radius:5px;
    display:block;
	text-transform: uppercase;
	font-weight:800;
}

.icon-heading h4{
	padding-left:80px;
	font-size:15px;
}

.icon-heading p{
	line-height:24px;
	padding-left:80px;
}

.icon-heading i{
	border-radius:10px;
	position:absolute;
	width:70px;
	height:70px;
	line-height:70px;
	margin-top:5px;
	text-align:center;
	font-size:24px;
}

.icon-heading amp-img{
	width:55px;
	height:55px;
	margin-left:0px;
	margin-top:10px;
	float:left;
}

.quote-style h4, .quote-style h5{
	font-weight:300;
	margin-left:25px;
	margin-right:25px;
	text-align:center;
	line-height:40px;
}

.rating{
	width:80px;
	margin:20px auto 20px auto;
	display:block; 
}


.half-column-left .half-left-img{
	position:absolute;
	border-radius:150px;
	margin-left:-50px;
	left:0px;
}

.half-column-left{
	padding-left:70px;
	padding-right:20px;
	min-height:150px;
    overflow:hidden;
}


.half-column-right .half-right-img{
	position:absolute;
	border-radius:150px;
	margin-right:-50px;
	right:0px;
}

.half-column-right{
	padding-right:70px;
	padding-left:20px;
	min-height:150px;
    overflow:hidden;
}

/*Gallery*/
.gallery-thumb{
	width:31%;
	float:left;
	margin-bottom:3%;
	box-sizing: border-box;
}
.gallery-thumb p{margin-bottom:10px; line-height:20px; padding-top:5px; text-align:center; font-size:13px;}
.gallery-round .gallery-thumb{border-radius:100px}
.gallery-wide .gallery-thumb-wide{margin-bottom:5px;}
.gallery-wide h4{
	position:absolute;
	background-color:rgba(0,0,0,0.8);
	color:#FFFFFF;
	z-index:99;
	height:50px;
	line-height:50px;
	margin-top:-55px;
	width:100%;
	padding-left:20px;
	font-weight:300;
	font-size:14px;
	pointer-events:none;
}


.gallery-thumb:nth-child(3n-1){
	margin-left:3%;
	margin-right:3%;
}

.gallery-text{font-size:12px; color:#939393; line-height:24px;}
.gallery-text i{font-size:11px; padding:0px 10px 0px 0px;}
.gallery-text em{padding:0px 15px 0px 0px; font-style:normal}


/*Splash Page*/
.splash-content .splash-logo{
	background-image:url(images/amp-logo.png);
	background-size:80px 80px;
	width:80px;
	height:80px;
	margin:-30px auto 20px auto;
}

.splash-content{
	position:fixed;
	width:240px;
	height:350px;
	left:50%;
	top:50%;
	margin-top:-140px;
	margin-left:-120px;
}

.splash-button{
	width:130px;
	margin:0 auto;
	text-align:center;
	height:40px;
	line-height:40px;
	font-size:12px;
}

/*Landing Content*/

.landing-logo{
	background-image:url(images/logo_light.png);
	background-size:160px 47px;
	margin:0 auto;
	height:47px;
	width:160px;
	margin-top:20px;
}

.landing-content{
	width:300px;
	margin:40px auto 30px auto;
}

.landing-content a{
	width:70px;
	height:70px;
	float:left;
	margin:0px 15px 60px 15px;
	border-radius:70px;
	line-height:70px;
	font-size:21px;
	text-align:center;
}

.landing-content a em{
	position:absolute;
	font-size:14px;
	width:70px;
	text-align:center;
	bottom:-60px;
	left:0px;
	right:0px;
	font-style:normal;
}

.body-bg{
	background-image:url(images/pictures_vertical/bg2.jpg);
	position:fixed;
	top:0px;
	left:0px;
	right:0px;
	bottom:0px;
}

/*Accordion Styles*/
.accordion h4{
	background-color:transparent;
	border:none;
}

.accordion h4{
	font-size:16px;
	line-height:40px;
}

.accordion h4 i{
	height:40px;
	line-height:40px;
	position:absolute;
	right:0px;
	font-size:12px;
}

.nested-accordion h4{
	font-size:14px;
}

section[expanded] .fa-plus{	transform:rotate(45deg);}
section[expanded] .fa-angle-down{	transform:rotate(180deg);}
section[expanded] .fa-chevron-down{	transform:rotate(180deg);}

/*Fonts*/
.demo-icons a{
	color:#FFFFFF; 
	width:20%;
	height:50px;
	float:left;
}
.demo-icons a i{
	color:#1f1f1f; 
	font-size:21px;
	width:50px;
	height:50px; 
	float:left; 
	text-align:center; 
	overflow:hidden;
}

/*User Notifications*/
.user-notification{
	text-align:left;
	padding-top:5px;
	padding-left:10px;
	padding-right:10px;
	background-color:#27ae60;
	height:50px;
	color:#FFFFFF;
	font-size:12px;
	line-height:24px;
	width:70%;
	float:left;
}

.user-notification button{
	background-color:#27ae60;
	color:#FFFFFF;
	height:55px;
	position:fixed;
	right:0px;
	bottom:60px;
	width:25%;
}

/*Inputs*/

.text-input{
	height:45px;
	line-height:45px;
	text-indent: 10px;
	border:solid 1px rgba(0,0,0,0.1);
	display:block;
	width:100%;
	font-size:12px;
}

.input-icon-field{
	height:45px;
	line-height:45px;
	text-indent: 50px;
	border:solid 1px rgba(0,0,0,0.1);
	display:block;
	width:100%;
	font-size:12px;
}

.input-icon i{
	position:absolute;
	z-index:9;
	height:45px;
	line-height:45px;
	text-align:center;
	width:45px;
	color:#666666;
}

.select-style {
    border: 1px solid rgba(0,0,0,0.1);
    width: 100%;
	height:45px;
	display:block;
    border-radius: 3px;
    overflow: hidden;
    background: #FFFFFF url("data:image/png;base64,R0lGODlhDwAUAIABAAAAAP///yH5BAEAAAEALAAAAAAPABQAAAIXjI+py+0Po5wH2HsXzmw//lHiSJZmUAAAOw==") no-repeat 95% 50%;
}

.select-style select {
	font-size:12px;
	line-height:35px;
    padding: 5px 15px;
    width: 100%;
    border: none;
    box-shadow: none;
    background-color:rgba(255,255,255,0);
    background-image: none;
    -webkit-appearance: none;
}

.select-style select:focus {
    outline: none;
}



/*Dropcaps*/

.dropcaps-1:first-letter{
    float:left;
    font-size:57px;
	padding:14px 15px 0px 0px;
    font-weight:800;
    color:#1f1f1f;
}

.dropcaps-2:first-letter{
    font-family: 'Times New Roman', sans-serif;
    float:left;
    font-size:42px;
	padding:15px 15px 0px 0px;
    font-weight:800;
    color:#1f1f1f;
}

.dropcaps-3:first-letter{
    background-color:#1f1f1f;
	padding:10px 15px 10px 15px;
	margin:5px 12px 0px 0px;
    float:left;
    font-size:24px;
    font-weight:800;
    color:#FFFFFF;
}

.dropcaps-4:first-letter{
    font-family: 'Times New Roman', sans-serif;
    font-weight:800;
    background-color:#1f1f1f;
	padding:8px 17px 8px 17px;
	margin:5px 12px 0px 0px;
    float:left;
    font-size:20px;
    font-weight:400;
    color:#FFFFFF;
}

/*Highlights*/
.highlight{margin-bottom:10px;}
.highlight span{padding:3px 5px 3px 5px; margin-right:2px;}
ol ul{	padding-left:5px;}
ol, ul{line-height:24px; margin-left:20px;}
.icon-list{list-style:none; margin-left:0px; padding-left:0px;}
.icon-list i{font-size:10px;}
.icon-list ul{list-style:none; padding-left:10px;}
.icon-list ul ul{padding-left:10px;}

/*Blockquotes*/
.blockquote-1{border-left:solid 3px #1f1f1f; padding:10px 0px 10px 20px;}
.blockquote-1 a{text-align:right; margin-top:-20px;  font-size:12px;}
.blockquote-2 .blockquote-image{position:absolute; border-radius:50px;}
.blockquote-2 h5{padding-left:60px;}
.blockquote-2 .first-icon{padding-left:60px;}
.blockquote-2 a{text-align:right; margin-top:-20px; font-size:12px;}
.blockquote-3 .blockquote-image{width:150px; border-radius:150px; margin:0 auto; display:block;}
.blockquote-3 h5{margin:10px 0px 10px 0px;}
.blockquote-3 .ratings{width:100px; margin:10px auto 10px auto;}
.blockquote-3 .ratings i{font-size:18px;}
.blockquote-4 i{font-size:24px; position:absolute; margin-top:10px;}
.blockquote-4 p{padding-left:50px;}
.blockquote-5 amp-img{width:50px; height:50px; margin:0 auto;}
.blockquote-5 h4{font-size:24px; font-weight:200;}
.blockquote-5 p{font-style:italic; max-width:80%; font-weight:300; margin:0 auto; color:#747474; font-size:16px; line-height:35px;}

/*Buttons*/
.button{
	display:inline-block;
	padding:13px 20px;
	margin:0px 0px 10px 0px;
	font-size:12px;
	transition:all 250ms ease;
}

.button-3d{
	display:inline-block;
	padding:15px 20px;
	margin:0px 0px 10px 0px;
	font-size:12px;
	transition:all 250ms ease;
	border-right:none;
	border-left:none;
	border-top:none;
	border-width:3px;
}

.button-round{border-radius:30px;}
.button-full{display: block; text-align: center;}
.button-center{width:140px; margin-left:auto; margin-right:auto; display:block; text-align:center; margin-bottom:30px;}
.button:hover{opacity:0.9; transition:all 250ms ease;}

.icon-square, .icon-round{
	width:40px;
	height:40px;
	line-height:40px;
	text-align:center;
	display:inline-block;
	margin-left:6px;
	margin-right:6px;
	margin-bottom:10px;
	font-size:14px;
}
.icon-square:hover, .icon-round:hover{opacity:0.9;}
.icon-round{border-radius:45px;}

/*Page 404*/
.page-404 h1{font-size:60px; line-height:70px; margin-top:70px;}
.page-404 a{margin-bottom:100px;}
.page-soon h1{font-size:60px; line-height:70px; margin-top:70px;}
.page-soon h6{font-size:24px;}
.page-soon .social-icons{margin-bottom:100px;}

/*Profile Page*/

.profile-gradient{
    background: -moz-linear-gradient(top,rgba(255,255,255,0) 0%,rgba(255,255,255,0.95) 75%,rgba(255,255,255,1) 100%);
    background: -webkit-linear-gradient(top,rgba(255,255,255,0) 0%,rgba(255,255,255,0.95) 75%,rgba(255,255,255,1) 100%);
    background: linear-gradient(to bottom,rgba(255,255,255,0) 0%,rgba(255,255,255,0.95) 75%,rgba(255,255,255,1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00ffffff',endColorstr='#ffffff',GradientType=0);
    height: 250px;
    margin-top: -235px;
}

.profile-overlay .profile-header{margin-top:-80px}
.profile-header h1{font-size:30px;}
.profile-header h6{letter-spacing:2px; opacity:0.5;}
.profile-header h5{font-size:12px;}
.profile-header i{margin-right:10px;}
.profile-header p{font-size:18px;}
.profile-followers a{float:left; width:33%; color:#1f1f1f; font-size:18px;}
.profile-followers em{display:block; font-style:normal; font-size:12px;}
.profile-thumb{margin-top:-50px; width:100px; margin-left:auto; margin-right:auto; display:block; border-radius:100px; border-radius:100px; border:solid 3px #FFFFFF;}

/*Timeline 1*/

.timeline-1{overflow:hidden; padding:20px }

.timeline-1 .timeline-deco{
	position:absolute;
	top:0px;
	left:50%;
	width:1px;
	bottom:0px;
	background-color:rgba(0,0,0,0.15);
}

.timeline-1 .timeline-icon{
	width:60px;
	height:60px;
	border-radius:60px;
	line-height:60px;
	text-align:center;
	font-size:18px;
	background-color:#FFFFFF;
	border:solid 1px rgba(0,0,0,0.2);
	margin:0px auto 30px auto;
}

.timeline-1 .container{background-color:#FFFFFF; padding:30px 0px 1px 0px}
.timeline-2{overflow:hidden; padding:50px 20px 0px 20px; }

.timeline-2 .timeline-deco{
	position:absolute;
	top:0px;
	left:50px;
	width:1px;
	bottom:0px;
	background-color:rgba(0,0,0,0.15);
}

.timeline-2 .timeline-icon{
	width:40px;
	height:40px;
	border-radius:40px;
	line-height:40px;
	text-align:center;
	font-size:18px;
	background-color:#FFFFFF;
	border:solid 1px rgba(0,0,0,0.2);
	margin-left:10px;
}

.timeline-2 .container{
	background-color:#FFFFFF; 
	margin-left:70px;
	margin-top:-60px;
	padding-bottom:30px;
}


/*News Slider*/

.news-slider .amp-carousel-button{display:none;}
.news-slider{margin-bottom:10px;}

/*News Thumbs*/

.news-thumbs .news-item{
	min-height:125px;
	color:#1f1f1f;
}

.news-thumbs .news-item .responsive-img{
	width:95px;
	position:absolute;
	margin-top:5px;
}

.news-thumbs .news-item h5{
	margin-left:110px;
	font-size:15px;
}

.news-thumbs .news-item p{
	margin-left:110px;
	line-height:27px;
	margin-bottom:0px;
	font-size:13px;
}

/*News Strip*/

.news-strip{
	background-color:#000000;
	padding:20px 0px 20px 0px;
	margin-bottom:30px;
}

.news-strip h5{
	font-weight:800;
	color:#FFFFFF;
	padding:0px 20px 20px 20px;
}

/*News Cateogry*/

.news-category{
	margin:0px 20px 0px 20px;
}

.news-category p{
	display:inline-block;
	padding:5px 25px 0px 25px;
	font-size:13px;
	margin:0px;
}

.news-category div{
	height:5px;
	width:100%;
}

/*News Block*/

.news-blocks .news-item{
	min-height:125px;
	color:#1f1f1f;
}

.news-blocks .news-item h5{
	font-size:18px;
	padding:15px 0px 5px 0px;
}

/*News full*/

.news-full .news-item{margin-top:1px;}

.news-full .news-item h6{
	position:absolute;
	background-color:rgba(0,0,0,0.8);
	bottom:0px;
	width:100%;
	color:#FFFFFF;
	padding:10px 10px 10px 10px;
}

.news-full .titles{
	position:absolute;
	background-color:#FFFFFF;
	width:250px;
	height:65px;
	margin-top:-65px;
}

.news-full h5{
	font-size:13px;
	padding:10px 20px 0px 20px;
	color:#000000;
}
.news-full em a{display:inline;}
.news-full em{font-size:10px; padding-left:20px; display:block;}
.news-full p{padding:10px 20px 0px 20px;}
.news-full .read-more{
	padding-right:20px;
	text-align:right;
	font-size:12px;
	padding-bottom:30px;
}

/*News Posts*/

.news-post-info{
	font-style:normal;
	font-size:12px;
	padding:5px 0px 15px 0px;
	display:block;
}

.news-post-info a{
	display:inline;
	
}

/*Contact Page*/

.contactField{
	font-family:'Roboto', sans-serif;
	height:40px;
	line-height:40px;
	line-height:100%;
	width:100%;
	display:block;
	border:solid 1px rgba(0,0,0,0.1);
	text-indent:10px;
	font-size:13px;
	transition:all 250ms ease;
	margin-bottom:20px;
}

.contactField:focus{
	border:solid 1px rgb(39, 174, 96);
	transition:all 250ms ease;
}

.contactTextarea{
	font-family:'Roboto', sans-serif;
	padding-top:10px;
	min-height:80px;
	line-height:40px;
	line-height:100%;
	width:100%;
	display:block;
	border:solid 1px rgba(0,0,0,0.1);
	text-indent:10px;
	font-size:13px;
	transition:all 250ms ease;
	margin-bottom:30px;
}

.contactTextarea:focus{
	transition:all 250ms ease;
	border:solid 1px rgb(39, 174, 96);
}

.field-title{
	font-size:13px; 
	margin-bottom:5px;
}

.field-title span{
	font-size:10px;
	color:#cacaca;
	position:absolute;
	right:0px;
	margin-top:2px;
}

.buttonWrap{
	width:100%;
	display:block;
	text-align:center;
	margin-bottom:30px;
    appearance:none;
    -webkit-appearance:none;
}

.contact-icon{
	color:#666666;
	line-height:30px;
}

.contact-icon i{
	color:#1f1f1f;
	width:30px;
}


/*Cover Pages*/

.cover-clear{height:40px;}

.cover-1{
	padding:30px 40px 0px 40px;
	border-top:solid 1px rgba(255,255,255,0.1);
}

.cover-1, .cover-2, .cover-4, .cover-5{
	border-top:solid 1px rgba(255,255,255,0.1);
}

.cover-1 h1{
	font-size:30px;
	color:#FFFFFF;
}

.cover-1 h6{
	font-size:16px;
	color:#FFFFFF;
	padding:10px 0px 30px 0px;
	font-weight:300;
}

.cover-1 p{
	font-size:15px;
	font-weight:300;
	color:#a7a7a7;
	line-height:35px;
	margin-bottom:50px;
}

.cover-1 .button{
	border:solid 1px rgba(255,255,255,0.2);
	color:#FFFFFF;
	margin-right:10px;
}

.cover-2{padding-top:0px;}

.cover-2 h1{
	color:#FFFFFF;
	font-size:30px;
	font-weight:300;
	text-align:center;
	padding-top:30px;
}

.cover-2 h6{
	color:#c1c1c1;
	font-style: italic;
	font-size:13px;
	font-weight:300;
	text-align:center;
	padding:0px 0px 20px 0px;
}

.cover-2 p{
	font-size:15px;
	text-align:center;
	line-height:36px;
	color:#c1c1c1;
	padding:30px 35px 40px 35px;
	font-weight:300;
}

.cover-3{
	padding:20px 20px 20px 20px;
	background-color:#FFFFFF;
	margin:20px;
	border-radius:7px;
}

.cover-3 amp-img{
	margin:0 auto;
	display:block;
}

.cover-3 h1{
	font-size:24px;
	text-align:center;
	padding:20px 0px 0px 0px;
}

.cover-3 em{
	font-size:12px;
	display:block;
	text-align:center;
	margin-bottom:20px;
}

.cover-3 p{
	text-align:center;
	font-size:16px;
	font-weight:300;
	padding:0px 5px 0px 5px;
}

.cover-3 .socials{
	transform:scale(0.8, 0.8);
	width:210px;
	margin:0 auto;
}

.cover-3 .socials a{
	margin-left:4px;
	margin-right:4px;
}

.cover-4 h1{
	color:#FFFFFF;
	text-align:center;
	font-weight:300;
	font-size:36px;
	margin:30px 0px 10px 0px;
}

.cover-4 em{
	color:#FFFFFF;
	text-align:center;
	font-style:normal;
	display: block;
	font-size:12px;
	text-transform: uppercase;
	letter-spacing:1px;
	font-weight:300;
}

.cover-4 strong{
	color:#969696;
	text-transform:uppercase;
	font-weight:800;
	font-size:12px;
	text-align:center;
	display:block;
	margin:20px 0px 30px 0px;
}
.cover-4 strong i{
	padding-right:10px
}

.cover-4 p{
	padding:40px 30px 40px 30px;
	color:#FFFFFF;
	line-height:36px;
	text-align:center;
	font-weight:300;
	font-size:16px;
}

.cover-4 a{
	font-size:13px;
	width:170px;
	margin:0 auto;
}

.cover-5 h1{
	color:#FFFFFF;
	font-size:40px;
	font-weight:300;
	text-align:center;
	padding-top:30px;
}

.cover-5 em{
	display:block;
	text-align:center;
	color:#FFFFFF;
	font-size:12px;
	margin-top:10px;
	font-style: normal;
}

.cover-5 p{
	padding:20px 30px 20px 30px;
	color:#a7a7a7;
	font-weight:300;
	text-align:center;
	font-size:16px;
	line-height:40px;
}

.cover-socials a{
	width:35px;
	height:35px;
	border-radius:35px;
	float:left;
	text-align:center;
	line-height:35px;
	font-size:12px;
	margin:0px 5px 0px 5px;
}

.cover-socials{
	width:230px;
	margin:40px auto 30px auto;
}












</style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

<body>		
	<header>
		<a href="index.php" class="header-logo"></a>
		<a href="contact.php" class="header-icon-2"><i class="icon-14 fa fa-envelope-o"></i></a>
		<a href="button-amp.php" class="header-icon-1"><i class="icon-12 fa fa-chevron-left"></i></a>
	</header>
	
	<nav class="footer-5-icons">
		<a href="button-amp.php" class="active-item"><i class="icon-16 fa fa-bolt"></i><em>Features</em></a>
		<a href="button-pages.php"><i class="icon-16 fa fa-bookmark"></i><em>Pages</em></a>
		<a href="index.php"><i class="icon-18 fa fa-home"></i><em>Home</em></a>
		<a href="button-media.php"><i class="fa fa-picture-o"></i><em>Media</em></a>
		<a href="index-news.php"><i class="icon-16 fa fa-newspaper-o"></i><em>News</em></a>
	</nav>
	
	<div class="page-content">
		<div class="page-content-scroll">

			<div class="heading-block bg-1">
				<h4>Instagram</h4>
				<p>Posts Embeds Powered by AMP</p>
				<div class="overlay"></div>
			</div>

			<div class="content">
				<amp-instagram class="full-bottom" data-shortcode="6oPeMaHXxg" width="1" height="1" layout="responsive"></amp-instagram>
			</div>

			<div class="heading-block bg-1">
				<h4>Instagram</h4>
				<p>Video Embeds Powered by AMP</p>
				<div class="overlay"></div>
			</div>

			<div class="content">
				<amp-instagram class="full-bottom" data-shortcode="6oL9ePnX7w" width="1" height="1" layout="responsive"></amp-instagram>
			</div>
				
			<div class="footer">
				<div class="decoration decoration-margins"></div>
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="decoration decoration-margins"></div>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					<a href="https://plus.google.com/u/2/105775801838187143320" class="google-bg"><i class="fa fa-google-plus"></i></a>
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>

			
		</div>
	</div>

	
</body>
</html>